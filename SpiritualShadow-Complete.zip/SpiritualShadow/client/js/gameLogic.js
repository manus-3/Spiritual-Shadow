// Spiritual Shadow - Advanced Game Logic and Mechanics

// Level configurations
const LEVEL_CONFIGS = {
    1: {
        name: "The Cursed Entrance",
        description: "Enter the realm of shadows and spirits",
        size: { width: 1600, height: 1200 },
        enemies: { spirits: 5, beasts: 2 },
        collectibles: 10,
        lightSources: 8,
        cursedZones: 15,
        puzzles: 2,
        boss: null,
        objectives: ["Collect 5 Spirit Shards", "Defeat 3 enemies", "Find the exit portal"]
    },
    2: {
        name: "The Whispering Halls",
        description: "Navigate through the haunted corridors",
        size: { width: 2000, height: 1400 },
        enemies: { spirits: 8, beasts: 4 },
        collectibles: 15,
        lightSources: 6,
        cursedZones: 25,
        puzzles: 3,
        boss: null,
        objectives: ["Solve 2 spirit puzzles", "Survive 5 minutes", "Collect Ancient Artifact"]
    },
    3: {
        name: "The Shadow Lord's Domain",
        description: "Face the master of this cursed realm",
        size: { width: 2400, height: 1600 },
        enemies: { spirits: 10, beasts: 6 },
        collectibles: 20,
        lightSources: 4,
        cursedZones: 35,
        puzzles: 4,
        boss: "Shadow Lord",
        objectives: ["Defeat the Shadow Lord", "Maintain light level above 20", "Collect 3 Shadow Fragments"]
    }
};

// Enemy AI behaviors
class EnemyAI {
    static behaviors = {
        WANDER: 'wander',
        CHASE: 'chase',
        PATROL: 'patrol',
        GUARD: 'guard',
        FLEE: 'flee'
    };

    static updateEnemy(enemy, player, scene) {
        const behavior = enemy.getData('behavior') || EnemyAI.behaviors.WANDER;
        const type = enemy.getData('type');
        
        switch (behavior) {
            case EnemyAI.behaviors.WANDER:
                EnemyAI.wanderBehavior(enemy);
                break;
            case EnemyAI.behaviors.CHASE:
                EnemyAI.chaseBehavior(enemy, player);
                break;
            case EnemyAI.behaviors.PATROL:
                EnemyAI.patrolBehavior(enemy);
                break;
            case EnemyAI.behaviors.GUARD:
                EnemyAI.guardBehavior(enemy, player);
                break;
            case EnemyAI.behaviors.FLEE:
                EnemyAI.fleeBehavior(enemy, player);
                break;
        }

        // Check for behavior changes based on distance to player
        const distance = Phaser.Math.Distance.Between(enemy.x, enemy.y, player.x, player.y);
        
        if (type === 'spirit') {
            if (distance < 150 && behavior !== EnemyAI.behaviors.CHASE) {
                enemy.setData('behavior', EnemyAI.behaviors.CHASE);
            } else if (distance > 300 && behavior === EnemyAI.behaviors.CHASE) {
                enemy.setData('behavior', EnemyAI.behaviors.WANDER);
            }
        } else if (type === 'beast') {
            if (distance < 200 && behavior !== EnemyAI.behaviors.CHASE) {
                enemy.setData('behavior', EnemyAI.behaviors.CHASE);
            } else if (distance > 400 && behavior === EnemyAI.behaviors.CHASE) {
                enemy.setData('behavior', EnemyAI.behaviors.WANDER);
            }
        }
    }

    static wanderBehavior(enemy) {
        if (Math.random() < 0.02) {
            const speed = enemy.getData('type') === 'spirit' ? 60 : 40;
            enemy.setVelocity(
                Phaser.Math.Between(-speed, speed),
                Phaser.Math.Between(-speed, speed)
            );
        }
    }

    static chaseBehavior(enemy, player) {
        const speed = enemy.getData('type') === 'spirit' ? 80 : 60;
        const angle = Phaser.Math.Angle.Between(enemy.x, enemy.y, player.x, player.y);
        enemy.setVelocity(Math.cos(angle) * speed, Math.sin(angle) * speed);
    }

    static patrolBehavior(enemy) {
        let patrolPoints = enemy.getData('patrolPoints');
        if (!patrolPoints) {
            patrolPoints = [
                { x: enemy.x - 200, y: enemy.y },
                { x: enemy.x + 200, y: enemy.y }
            ];
            enemy.setData('patrolPoints', patrolPoints);
            enemy.setData('currentPatrolTarget', 0);
        }

        const currentTarget = enemy.getData('currentPatrolTarget');
        const target = patrolPoints[currentTarget];
        const distance = Phaser.Math.Distance.Between(enemy.x, enemy.y, target.x, target.y);

        if (distance < 50) {
            enemy.setData('currentPatrolTarget', (currentTarget + 1) % patrolPoints.length);
        } else {
            const speed = 40;
            const angle = Phaser.Math.Angle.Between(enemy.x, enemy.y, target.x, target.y);
            enemy.setVelocity(Math.cos(angle) * speed, Math.sin(angle) * speed);
        }
    }

    static guardBehavior(enemy, player) {
        const guardRadius = 150;
        const distance = Phaser.Math.Distance.Between(enemy.x, enemy.y, player.x, player.y);
        
        if (distance < guardRadius) {
            EnemyAI.chaseBehavior(enemy, player);
        } else {
            enemy.setVelocity(0, 0);
        }
    }

    static fleeBehavior(enemy, player) {
        const speed = 100;
        const angle = Phaser.Math.Angle.Between(player.x, player.y, enemy.x, enemy.y);
        enemy.setVelocity(Math.cos(angle) * speed, Math.sin(angle) * speed);
    }
}

// Combat system
class CombatSystem {
    static playerAttack(player, enemies, scene) {
        if (gameState.player.energy < 10) return false;
        
        gameState.player.energy -= 10;
        const attackRange = 120;
        let hitEnemies = 0;

        enemies.children.entries.forEach(enemy => {
            const distance = Phaser.Math.Distance.Between(player.x, player.y, enemy.x, enemy.y);
            if (distance < attackRange) {
                CombatSystem.damageEnemy(enemy, 25, scene);
                hitEnemies++;
            }
        });

        // Create attack effect
        CombatSystem.createAttackEffect(player, scene);
        
        return hitEnemies > 0;
    }

    static damageEnemy(enemy, damage, scene) {
        const currentHp = enemy.getData('hp');
        const newHp = currentHp - damage;
        enemy.setData('hp', newHp);

        // Visual damage effect
        scene.tweens.add({
            targets: enemy,
            tint: 0xff0000,
            duration: 200,
            yoyo: true,
            onComplete: () => {
                enemy.clearTint();
            }
        });

        // Knockback
        const angle = Phaser.Math.Angle.Between(scene.player.x, scene.player.y, enemy.x, enemy.y);
        enemy.setVelocity(Math.cos(angle) * 200, Math.sin(angle) * 200);

        if (newHp <= 0) {
            CombatSystem.destroyEnemy(enemy, scene);
        }
    }

    static destroyEnemy(enemy, scene) {
        const type = enemy.getData('type');
        const reward = type === 'spirit' ? 15 : 25;
        
        gameState.player.soulCoins += reward;
        gameState.player.experience += reward;

        // Death effect
        scene.tweens.add({
            targets: enemy,
            alpha: 0,
            scale: 0.5,
            duration: 500,
            onComplete: () => {
                enemy.destroy();
            }
        });

        // Drop items occasionally
        if (Math.random() < 0.3) {
            CombatSystem.dropItem(enemy.x, enemy.y, scene);
        }
    }

    static dropItem(x, y, scene) {
        const itemTypes = ['spiritShard', 'potion', 'shadowFragment'];
        const itemType = Phaser.Utils.Array.GetRandom(itemTypes);
        const droppedItem = scene.collectibles.create(x, y, itemType);
        droppedItem.setData('type', itemType);
        
        // Bounce effect
        scene.tweens.add({
            targets: droppedItem,
            y: y - 20,
            duration: 300,
            yoyo: true,
            ease: 'Bounce'
        });
    }

    static createAttackEffect(player, scene) {
        const effect = scene.add.circle(player.x, player.y, 60, 0xffffff, 0.3);
        scene.tweens.add({
            targets: effect,
            scale: 2,
            alpha: 0,
            duration: 300,
            onComplete: () => {
                effect.destroy();
            }
        });
    }
}

// Puzzle system
class PuzzleSystem {
    static createPuzzle(x, y, scene, type = 'rune') {
        const puzzle = scene.puzzleElements.create(x, y, 'puzzleElement');
        puzzle.setData('type', type);
        puzzle.setData('solved', false);
        puzzle.setData('sequence', PuzzleSystem.generateSequence(type));
        puzzle.setData('playerSequence', []);
        
        puzzle.setInteractive();
        puzzle.on('pointerdown', () => {
            PuzzleSystem.interactWithPuzzle(puzzle, scene);
        });

        return puzzle;
    }

    static generateSequence(type) {
        switch (type) {
            case 'rune':
                return [1, 3, 2, 4]; // Sequence of rune activations
            case 'light':
                return [2, 1, 4, 3]; // Light pattern sequence
            case 'spirit':
                return [4, 2, 1, 3]; // Spirit communication sequence
            default:
                return [1, 2, 3, 4];
        }
    }

    static interactWithPuzzle(puzzle, scene) {
        if (puzzle.getData('solved')) return;

        const playerSequence = puzzle.getData('playerSequence');
        const correctSequence = puzzle.getData('sequence');
        const nextInput = playerSequence.length + 1;

        playerSequence.push(nextInput);
        puzzle.setData('playerSequence', playerSequence);

        // Visual feedback
        scene.tweens.add({
            targets: puzzle,
            scale: 1.2,
            duration: 100,
            yoyo: true
        });

        // Check if sequence is correct so far
        let correct = true;
        for (let i = 0; i < playerSequence.length; i++) {
            if (playerSequence[i] !== correctSequence[i]) {
                correct = false;
                break;
            }
        }

        if (!correct) {
            // Wrong sequence, reset
            puzzle.setData('playerSequence', []);
            puzzle.setTint(0xff0000);
            scene.time.delayedCall(500, () => {
                puzzle.clearTint();
            });
        } else if (playerSequence.length === correctSequence.length) {
            // Puzzle solved!
            PuzzleSystem.solvePuzzle(puzzle, scene);
        } else {
            // Correct so far, continue
            puzzle.setTint(0x00ff00);
            scene.time.delayedCall(200, () => {
                puzzle.clearTint();
            });
        }
    }

    static solvePuzzle(puzzle, scene) {
        puzzle.setData('solved', true);
        puzzle.setTint(0xffd700);
        
        // Reward player
        gameState.player.soulCoins += 50;
        gameState.player.experience += 30;
        gameState.player.lightLevel = Math.min(100, gameState.player.lightLevel + 20);

        // Create reward effect
        const rewardText = scene.add.text(puzzle.x, puzzle.y - 50, '+50 Soul Coins', {
            fontSize: '16px',
            fill: '#FFD700'
        }).setOrigin(0.5);

        scene.tweens.add({
            targets: rewardText,
            y: puzzle.y - 100,
            alpha: 0,
            duration: 1500,
            onComplete: () => {
                rewardText.destroy();
            }
        });

        // Spawn bonus items
        for (let i = 0; i < 3; i++) {
            const angle = (i * 120) * Math.PI / 180;
            const distance = 80;
            const itemX = puzzle.x + Math.cos(angle) * distance;
            const itemY = puzzle.y + Math.sin(angle) * distance;
            
            const bonusItem = scene.collectibles.create(itemX, itemY, 'spiritShard');
            bonusItem.setData('type', 'spiritShard');
        }
    }
}

// Level progression system
class LevelManager {
    static currentLevel = 1;
    static objectives = [];
    static completedObjectives = [];

    static loadLevel(levelNumber, scene) {
        const config = LEVEL_CONFIGS[levelNumber];
        if (!config) return false;

        LevelManager.currentLevel = levelNumber;
        LevelManager.objectives = [...config.objectives];
        LevelManager.completedObjectives = [];

        // Set world bounds
        scene.physics.world.setBounds(0, 0, config.size.width, config.size.height);
        scene.cameras.main.setBounds(0, 0, config.size.width, config.size.height);

        // Clear existing level
        LevelManager.clearLevel(scene);

        // Generate new level
        LevelManager.generateLevel(config, scene);

        // Update UI
        LevelManager.updateObjectivesUI(scene);

        return true;
    }

    static clearLevel(scene) {
        if (scene.enemies) scene.enemies.clear(true, true);
        if (scene.collectibles) scene.collectibles.clear(true, true);
        if (scene.lightSources) scene.lightSources.clear(true, true);
        if (scene.cursedZones) scene.cursedZones.clear(true, true);
        if (scene.puzzleElements) scene.puzzleElements.clear(true, true);
    }

    static generateLevel(config, scene) {
        // Create cursed zones
        scene.cursedZones = scene.physics.add.staticGroup();
        for (let i = 0; i < config.cursedZones; i++) {
            const x = Phaser.Math.Between(100, config.size.width - 100);
            const y = Phaser.Math.Between(100, config.size.height - 100);
            scene.cursedZones.create(x, y, 'cursedTile');
        }

        // Create light sources
        scene.lightSources = scene.physics.add.staticGroup();
        for (let i = 0; i < config.lightSources; i++) {
            const x = Phaser.Math.Between(200, config.size.width - 200);
            const y = Phaser.Math.Between(200, config.size.height - 200);
            scene.lightSources.create(x, y, 'lightSource');
        }

        // Create puzzles
        scene.puzzleElements = scene.physics.add.staticGroup();
        for (let i = 0; i < config.puzzles; i++) {
            const x = Phaser.Math.Between(300, config.size.width - 300);
            const y = Phaser.Math.Between(300, config.size.height - 300);
            PuzzleSystem.createPuzzle(x, y, scene);
        }

        // Create enemies
        scene.enemies = scene.physics.add.group();
        
        // Spirits
        for (let i = 0; i < config.enemies.spirits; i++) {
            const x = Phaser.Math.Between(100, config.size.width - 100);
            const y = Phaser.Math.Between(100, config.size.height - 100);
            const spirit = scene.enemies.create(x, y, 'spiritEnemy');
            spirit.setData('type', 'spirit');
            spirit.setData('hp', 30 + (LevelManager.currentLevel * 10));
            spirit.setData('behavior', EnemyAI.behaviors.WANDER);
        }

        // Beasts
        for (let i = 0; i < config.enemies.beasts; i++) {
            const x = Phaser.Math.Between(100, config.size.width - 100);
            const y = Phaser.Math.Between(100, config.size.height - 100);
            const beast = scene.enemies.create(x, y, 'beastEnemy');
            beast.setData('type', 'beast');
            beast.setData('hp', 60 + (LevelManager.currentLevel * 15));
            beast.setData('behavior', EnemyAI.behaviors.PATROL);
        }

        // Create collectibles
        scene.collectibles = scene.physics.add.group();
        const collectibleTypes = ['artifact', 'spiritShard', 'potion', 'shadowFragment', 'soulCoin'];
        for (let i = 0; i < config.collectibles; i++) {
            const x = Phaser.Math.Between(100, config.size.width - 100);
            const y = Phaser.Math.Between(100, config.size.height - 100);
            const type = Phaser.Utils.Array.GetRandom(collectibleTypes);
            const collectible = scene.collectibles.create(x, y, type);
            collectible.setData('type', type);
        }

        // Create boss if specified
        if (config.boss) {
            LevelManager.createBoss(config.boss, scene);
        }

        // Create exit portal
        LevelManager.createExitPortal(config.size.width - 100, config.size.height - 100, scene);
    }

    static createBoss(bossType, scene) {
        const x = scene.physics.world.bounds.width / 2;
        const y = scene.physics.world.bounds.height / 2;
        
        const boss = scene.enemies.create(x, y, 'beastEnemy'); // Use beast sprite for now
        boss.setScale(2);
        boss.setData('type', 'boss');
        boss.setData('bossType', bossType);
        boss.setData('hp', 200 + (LevelManager.currentLevel * 50));
        boss.setData('maxHp', 200 + (LevelManager.currentLevel * 50));
        boss.setData('behavior', EnemyAI.behaviors.GUARD);
        boss.setTint(0x800080); // Purple tint for boss
    }

    static createExitPortal(x, y, scene) {
        const portal = scene.add.circle(x, y, 40, 0x00ffff, 0.7);
        portal.setData('type', 'exit');
        
        // Portal animation
        scene.tweens.add({
            targets: portal,
            scale: 1.2,
            alpha: 0.5,
            duration: 1000,
            yoyo: true,
            repeat: -1
        });

        // Make portal interactive
        portal.setInteractive(new Phaser.Geom.Circle(0, 0, 40), Phaser.Geom.Circle.Contains);
        portal.on('pointerdown', () => {
            if (LevelManager.canExitLevel()) {
                LevelManager.completeLevel(scene);
            } else {
                scene.showMessage("Complete all objectives before exiting!");
            }
        });

        scene.exitPortal = portal;
    }

    static canExitLevel() {
        return LevelManager.completedObjectives.length >= LevelManager.objectives.length;
    }

    static completeLevel(scene) {
        // Level completion rewards
        const baseReward = 100 * LevelManager.currentLevel;
        const timeBonus = Math.max(0, 300 - Math.floor(scene.time.now / 1000)) * 5;
        const totalReward = baseReward + timeBonus;

        gameState.player.soulCoins += totalReward;
        gameState.player.experience += totalReward;
        gameState.player.level = Math.max(gameState.player.level, LevelManager.currentLevel);

        // Show completion screen
        LevelManager.showLevelComplete(scene, totalReward);
    }

    static showLevelComplete(scene, reward) {
        const overlay = scene.add.rectangle(400, 300, 800, 600, 0x000000, 0.8).setScrollFactor(0);
        
        const title = scene.add.text(400, 200, 'Level Complete!', {
            fontSize: '48px',
            fill: '#FFD700',
            fontFamily: 'serif'
        }).setOrigin(0.5).setScrollFactor(0);

        const rewardText = scene.add.text(400, 280, `Reward: ${reward} Soul Coins`, {
            fontSize: '24px',
            fill: '#32CD32',
            fontFamily: 'serif'
        }).setOrigin(0.5).setScrollFactor(0);

        const nextBtn = scene.add.text(300, 400, 'Next Level', {
            fontSize: '20px',
            fill: '#FFF',
            backgroundColor: '#006600',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setScrollFactor(0).setInteractive();

        const menuBtn = scene.add.text(500, 400, 'Main Menu', {
            fontSize: '20px',
            fill: '#FFF',
            backgroundColor: '#444',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setScrollFactor(0).setInteractive();

        nextBtn.on('pointerdown', () => {
            const nextLevel = LevelManager.currentLevel + 1;
            if (LEVEL_CONFIGS[nextLevel]) {
                LevelManager.loadLevel(nextLevel, scene);
                overlay.destroy();
                title.destroy();
                rewardText.destroy();
                nextBtn.destroy();
                menuBtn.destroy();
            } else {
                scene.scene.start('LobbyScene');
            }
        });

        menuBtn.on('pointerdown', () => {
            scene.scene.start('LobbyScene');
        });
    }

    static updateObjectivesUI(scene) {
        // Remove existing objectives UI
        if (scene.objectivesUI) {
            scene.objectivesUI.destroy();
        }

        // Create new objectives UI
        const uiContainer = scene.add.container(20, 120).setScrollFactor(0);
        
        const title = scene.add.text(0, 0, 'Objectives:', {
            fontSize: '18px',
            fill: '#FFD700',
            fontFamily: 'serif'
        });
        uiContainer.add(title);

        LevelManager.objectives.forEach((objective, index) => {
            const completed = LevelManager.completedObjectives.includes(objective);
            const color = completed ? '#32CD32' : '#FFF';
            const prefix = completed ? '✓' : '○';
            
            const objectiveText = scene.add.text(0, 30 + (index * 25), `${prefix} ${objective}`, {
                fontSize: '14px',
                fill: color,
                fontFamily: 'serif'
            });
            uiContainer.add(objectiveText);
        });

        scene.objectivesUI = uiContainer;
    }

    static checkObjective(objective) {
        if (!LevelManager.completedObjectives.includes(objective)) {
            LevelManager.completedObjectives.push(objective);
            return true;
        }
        return false;
    }
}

// Export for use in main game
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        LEVEL_CONFIGS,
        EnemyAI,
        CombatSystem,
        PuzzleSystem,
        LevelManager
    };
}

