// Spiritual Shadow - Tutorial Level

class TutorialScene extends Phaser.Scene {
    constructor() {
        super({ key: 'TutorialScene' });
        this.tutorialStep = 0;
        this.tutorialSteps = [
            {
                title: "Welcome to Spiritual Shadow",
                text: "You are a shadow warrior in a cursed realm. Use WASD or arrow keys to move.",
                action: "move",
                completed: false
            },
            {
                title: "Managing Your Light",
                text: "Your light level decreases over time. Find light sources to restore it.",
                action: "light",
                completed: false
            },
            {
                title: "Combat Basics",
                text: "Press SPACE to attack nearby enemies. Watch your energy!",
                action: "attack",
                completed: false
            },
            {
                title: "Collecting Items",
                text: "Walk over items to collect them. They restore health and provide resources.",
                action: "collect",
                completed: false
            },
            {
                title: "Avoiding Cursed Zones",
                text: "Dark areas drain your light and energy. Avoid them when possible.",
                action: "cursed",
                completed: false
            },
            {
                title: "Solving Puzzles",
                text: "Click on puzzle elements to solve them. They provide valuable rewards.",
                action: "puzzle",
                completed: false
            },
            {
                title: "Tutorial Complete",
                text: "You're ready to face the shadows! Good luck, warrior.",
                action: "complete",
                completed: false
            }
        ];
    }

    preload() {
        // Load tutorial-specific assets
        this.load.image('tutorialBg', 'assets/images/lobby_background.png');
        this.load.image('arrow', 'assets/images/play_button.png'); // Reuse as arrow
        
        // Load all game assets
        this.load.image('player', 'assets/images/player_shadow_warrior.png');
        this.load.image('cursedTile', 'assets/images/cursed_zone_tile.png');
        this.load.image('lightSource', 'assets/images/light_source_small.png');
        this.load.image('puzzleElement', 'assets/images/puzzle_element.png');
        this.load.image('spiritEnemy', 'assets/images/enemy_wandering_spirit.png');
        this.load.image('spiritShard', 'assets/images/spirit_shard_icon.png');
        this.load.image('potion', 'assets/images/potion_icon.png');
    }

    create() {
        // Create tutorial world
        this.createTutorialWorld();
        this.createPlayer();
        this.createTutorialElements();
        this.createUI();
        this.setupControls();
        
        // Start tutorial
        this.showTutorialStep();
        
        // Physics setup
        this.physics.world.setBounds(0, 0, 1200, 800);
        this.cameras.main.setBounds(0, 0, 1200, 800);
        this.cameras.main.startFollow(this.player);
    }

    createTutorialWorld() {
        // Background
        this.add.image(600, 400, 'tutorialBg').setDisplaySize(1200, 800).setAlpha(0.3);
        
        // Create safe tutorial area
        const graphics = this.add.graphics();
        graphics.fillStyle(0x2a2a2a);
        graphics.fillRect(0, 0, 1200, 800);
    }

    createPlayer() {
        this.player = this.physics.add.sprite(100, 400, 'player');
        this.player.setCollideWorldBounds(true);
        this.player.setScale(1.5);
        
        // Tutorial player stats
        this.player.hp = 100;
        this.player.energy = 100;
        this.player.lightLevel = 50;
    }

    createTutorialElements() {
        // Movement area indicator
        this.movementZone = this.add.rectangle(300, 400, 200, 200, 0x004400, 0.3);
        this.movementZone.setStrokeStyle(2, 0x00ff00);
        
        // Light source for tutorial
        this.lightSources = this.physics.add.staticGroup();
        this.tutorialLight = this.lightSources.create(500, 300, 'lightSource');
        
        // Enemy for combat tutorial
        this.enemies = this.physics.add.group();
        this.tutorialEnemy = this.enemies.create(700, 400, 'spiritEnemy');
        this.tutorialEnemy.setData('type', 'spirit');
        this.tutorialEnemy.setData('hp', 30);
        this.tutorialEnemy.setVelocity(0, 0); // Stationary for tutorial
        
        // Collectible items
        this.collectibles = this.physics.add.group();
        this.tutorialPotion = this.collectibles.create(900, 300, 'potion');
        this.tutorialPotion.setData('type', 'potion');
        this.tutorialShard = this.collectibles.create(900, 500, 'spiritShard');
        this.tutorialShard.setData('type', 'spiritShard');
        
        // Cursed zone
        this.cursedZones = this.physics.add.staticGroup();
        this.tutorialCursed = this.cursedZones.create(500, 600, 'cursedTile');
        
        // Puzzle element
        this.puzzleElements = this.physics.add.staticGroup();
        this.tutorialPuzzle = this.puzzleElements.create(1000, 200, 'puzzleElement');
        this.tutorialPuzzle.setInteractive();
        this.tutorialPuzzle.setData('solved', false);
        
        // Tutorial arrows and indicators
        this.indicators = this.add.group();
    }

    createUI() {
        // Tutorial UI container
        this.tutorialUI = this.add.container(0, 0).setScrollFactor(0);
        
        // Tutorial panel
        this.tutorialPanel = this.add.rectangle(400, 100, 700, 120, 0x000000, 0.8).setScrollFactor(0);
        this.tutorialTitle = this.add.text(400, 70, '', {
            fontSize: '20px',
            fill: '#FFD700',
            fontFamily: 'serif',
            align: 'center'
        }).setOrigin(0.5).setScrollFactor(0);
        
        this.tutorialText = this.add.text(400, 110, '', {
            fontSize: '16px',
            fill: '#FFF',
            fontFamily: 'serif',
            align: 'center',
            wordWrap: { width: 650 }
        }).setOrigin(0.5).setScrollFactor(0);
        
        // Progress indicator
        this.progressText = this.add.text(750, 50, '', {
            fontSize: '14px',
            fill: '#AAA',
            fontFamily: 'serif'
        }).setScrollFactor(0);
        
        // Player stats (simplified for tutorial)
        this.add.text(20, 20, 'HP:', { fontSize: '16px', fill: '#FFF' }).setScrollFactor(0);
        this.hpBar = this.add.rectangle(80, 30, 100, 15, 0xFF0000).setScrollFactor(0);
        
        this.add.text(20, 50, 'Energy:', { fontSize: '16px', fill: '#FFF' }).setScrollFactor(0);
        this.energyBar = this.add.rectangle(80, 60, 100, 15, 0x0000FF).setScrollFactor(0);
        
        this.add.text(20, 80, 'Light:', { fontSize: '16px', fill: '#FFF' }).setScrollFactor(0);
        this.lightBar = this.add.rectangle(80, 90, 100, 15, 0xFFFF00).setScrollFactor(0);
        
        // Skip tutorial button
        this.skipButton = this.add.text(750, 550, 'Skip Tutorial', {
            fontSize: '16px',
            fill: '#FFF',
            backgroundColor: '#666',
            padding: { x: 10, y: 5 }
        }).setScrollFactor(0).setInteractive();
        
        this.skipButton.on('pointerdown', () => {
            this.scene.start('GameScene');
        });
    }

    setupControls() {
        // Keyboard controls
        this.cursors = this.input.keyboard.createCursorKeys();
        this.wasd = this.input.keyboard.addKeys('W,S,A,D');
        this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        
        // Touch controls
        this.input.on('pointerdown', (pointer) => {
            if (this.tutorialStep === 0) {
                this.moveToPointer(pointer);
            }
        });

        // Collision detection
        this.physics.add.overlap(this.player, this.collectibles, this.collectItem, null, this);
        this.physics.add.overlap(this.player, this.lightSources, this.restoreLight, null, this);
        this.physics.add.overlap(this.player, this.cursedZones, this.enterCursedZone, null, this);
        this.physics.add.overlap(this.player, this.enemies, this.playerEnemyCollision, null, this);
        
        // Puzzle interaction
        this.tutorialPuzzle.on('pointerdown', () => {
            if (this.tutorialStep === 5 && !this.tutorialPuzzle.getData('solved')) {
                this.solveTutorialPuzzle();
            }
        });
    }

    update() {
        this.handlePlayerMovement();
        this.updateUI();
        this.checkTutorialProgress();
        
        // Light decay (slower in tutorial)
        if (this.time.now % 2000 < 16) { // Every 2 seconds
            this.player.lightLevel = Math.max(0, this.player.lightLevel - 1);
        }
    }

    handlePlayerMovement() {
        const speed = 150;
        let moved = false;
        
        if (this.cursors.left.isDown || this.wasd.A.isDown) {
            this.player.setVelocityX(-speed);
            moved = true;
        } else if (this.cursors.right.isDown || this.wasd.D.isDown) {
            this.player.setVelocityX(speed);
            moved = true;
        } else {
            this.player.setVelocityX(0);
        }
        
        if (this.cursors.up.isDown || this.wasd.W.isDown) {
            this.player.setVelocityY(-speed);
            moved = true;
        } else if (this.cursors.down.isDown || this.wasd.S.isDown) {
            this.player.setVelocityY(speed);
            moved = true;
        } else {
            this.player.setVelocityY(0);
        }
        
        // Check movement tutorial step
        if (moved && this.tutorialStep === 0 && !this.tutorialSteps[0].completed) {
            this.completeTutorialStep(0);
        }
        
        // Attack
        if (this.spaceKey.isDown && this.tutorialStep === 2) {
            this.playerAttack();
        }
    }

    moveToPointer(pointer) {
        const distance = Phaser.Math.Distance.Between(this.player.x, this.player.y, pointer.worldX, pointer.worldY);
        if (distance > 50) {
            this.physics.moveToObject(this.player, pointer, 150);
        }
    }

    updateUI() {
        // Update health bar
        const hpPercent = this.player.hp / 100;
        this.hpBar.setScale(hpPercent, 1);
        
        // Update energy bar
        const energyPercent = this.player.energy / 100;
        this.energyBar.setScale(energyPercent, 1);
        
        // Update light bar
        const lightPercent = this.player.lightLevel / 100;
        this.lightBar.setScale(lightPercent, 1);
        
        // Update progress
        this.progressText.setText(`Step ${this.tutorialStep + 1} of ${this.tutorialSteps.length}`);
    }

    checkTutorialProgress() {
        const currentStep = this.tutorialSteps[this.tutorialStep];
        
        switch (currentStep.action) {
            case 'light':
                // Check if player is near light source
                const lightDistance = Phaser.Math.Distance.Between(
                    this.player.x, this.player.y,
                    this.tutorialLight.x, this.tutorialLight.y
                );
                if (lightDistance < 100 && !currentStep.completed) {
                    this.completeTutorialStep(this.tutorialStep);
                }
                break;
                
            case 'cursed':
                // Check if player entered cursed zone
                const cursedDistance = Phaser.Math.Distance.Between(
                    this.player.x, this.player.y,
                    this.tutorialCursed.x, this.tutorialCursed.y
                );
                if (cursedDistance < 50 && !currentStep.completed) {
                    this.completeTutorialStep(this.tutorialStep);
                }
                break;
        }
    }

    showTutorialStep() {
        const step = this.tutorialSteps[this.tutorialStep];
        
        this.tutorialTitle.setText(step.title);
        this.tutorialText.setText(step.text);
        
        // Clear previous indicators
        this.indicators.clear(true);
        
        // Add visual indicators based on step
        switch (step.action) {
            case 'move':
                this.createArrowIndicator(this.movementZone.x, this.movementZone.y - 100);
                break;
            case 'light':
                this.createArrowIndicator(this.tutorialLight.x, this.tutorialLight.y - 80);
                break;
            case 'attack':
                this.createArrowIndicator(this.tutorialEnemy.x, this.tutorialEnemy.y - 80);
                break;
            case 'collect':
                this.createArrowIndicator(this.tutorialPotion.x, this.tutorialPotion.y - 60);
                break;
            case 'cursed':
                this.createArrowIndicator(this.tutorialCursed.x, this.tutorialCursed.y - 80);
                break;
            case 'puzzle':
                this.createArrowIndicator(this.tutorialPuzzle.x, this.tutorialPuzzle.y - 80);
                break;
        }
    }

    createArrowIndicator(x, y) {
        const arrow = this.add.image(x, y, 'arrow').setScale(0.5);
        arrow.setTint(0xFFFF00);
        
        // Bounce animation
        this.tweens.add({
            targets: arrow,
            y: y - 20,
            duration: 800,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
        
        this.indicators.add(arrow);
    }

    completeTutorialStep(stepIndex) {
        this.tutorialSteps[stepIndex].completed = true;
        
        // Visual feedback
        this.tutorialPanel.setStrokeStyle(3, 0x00FF00);
        this.time.delayedCall(500, () => {
            this.tutorialPanel.setStrokeStyle(0);
        });
        
        // Move to next step
        this.time.delayedCall(1500, () => {
            this.nextTutorialStep();
        });
    }

    nextTutorialStep() {
        this.tutorialStep++;
        
        if (this.tutorialStep >= this.tutorialSteps.length) {
            this.completeTutorial();
        } else {
            this.showTutorialStep();
        }
    }

    completeTutorial() {
        // Tutorial completion screen
        const overlay = this.add.rectangle(400, 300, 800, 600, 0x000000, 0.8).setScrollFactor(0);
        
        const title = this.add.text(400, 250, 'Tutorial Complete!', {
            fontSize: '36px',
            fill: '#FFD700',
            fontFamily: 'serif'
        }).setOrigin(0.5).setScrollFactor(0);
        
        const subtitle = this.add.text(400, 300, 'You are now ready to face the shadows!', {
            fontSize: '18px',
            fill: '#FFF',
            fontFamily: 'serif'
        }).setOrigin(0.5).setScrollFactor(0);
        
        const startBtn = this.add.text(400, 380, 'Start Game', {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#006600',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setScrollFactor(0).setInteractive();
        
        startBtn.on('pointerdown', () => {
            this.scene.start('GameScene');
        });
        
        // Give tutorial completion reward
        gameState.player.soulCoins += 100;
        gameState.player.experience += 50;
    }

    // Tutorial-specific methods
    collectItem(player, item) {
        const type = item.getData('type');
        
        if (type === 'potion' && this.tutorialStep === 3) {
            this.player.hp = Math.min(100, this.player.hp + 20);
            this.completeTutorialStep(3);
        }
        
        item.destroy();
    }

    restoreLight(player, lightSource) {
        this.player.lightLevel = Math.min(100, this.player.lightLevel + 15);
        this.player.energy = Math.min(100, this.player.energy + 10);
    }

    enterCursedZone(player, cursedZone) {
        this.player.lightLevel = Math.max(0, this.player.lightLevel - 3);
        this.player.energy = Math.max(0, this.player.energy - 2);
    }

    playerEnemyCollision(player, enemy) {
        // Minimal damage in tutorial
        this.player.hp -= 5;
        
        // Knockback
        const angle = Phaser.Math.Angle.Between(enemy.x, enemy.y, player.x, player.y);
        player.setVelocity(Math.cos(angle) * 200, Math.sin(angle) * 200);
    }

    playerAttack() {
        if (this.player.energy < 10) return;
        
        this.player.energy -= 10;
        
        // Check if enemy is in range
        const distance = Phaser.Math.Distance.Between(
            this.player.x, this.player.y,
            this.tutorialEnemy.x, this.tutorialEnemy.y
        );
        
        if (distance < 100) {
            // Damage enemy
            const currentHp = this.tutorialEnemy.getData('hp');
            this.tutorialEnemy.setData('hp', currentHp - 20);
            
            // Visual effect
            this.tutorialEnemy.setTint(0xff0000);
            this.time.delayedCall(200, () => {
                this.tutorialEnemy.clearTint();
            });
            
            if (currentHp <= 20) {
                this.tutorialEnemy.destroy();
                this.completeTutorialStep(2);
            }
        }
    }

    solveTutorialPuzzle() {
        this.tutorialPuzzle.setData('solved', true);
        this.tutorialPuzzle.setTint(0xFFD700);
        
        // Reward
        this.player.lightLevel = Math.min(100, this.player.lightLevel + 20);
        
        this.completeTutorialStep(5);
    }
}

