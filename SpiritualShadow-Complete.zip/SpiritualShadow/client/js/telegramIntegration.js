// Spiritual Shadow - Telegram Mini App Integration

class TelegramIntegration {
    constructor() {
        this.tg = window.Telegram?.WebApp;
        this.user = null;
        this.isInitialized = false;
        this.serverUrl = 'http://localhost:3000'; // Change for production
    }

    // Initialize Telegram Mini App
    init() {
        if (!this.tg) {
            console.warn('Telegram WebApp not available, using mock data');
            this.initMockData();
            return;
        }

        try {
            // Initialize Telegram WebApp
            this.tg.ready();
            this.tg.expand();
            
            // Set theme
            this.setupTheme();
            
            // Get user data
            this.user = this.tg.initDataUnsafe?.user;
            
            // Setup main button
            this.setupMainButton();
            
            // Setup back button
            this.setupBackButton();
            
            // Setup haptic feedback
            this.setupHaptics();
            
            // Setup viewport
            this.setupViewport();
            
            this.isInitialized = true;
            console.log('Telegram WebApp initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize Telegram WebApp:', error);
            this.initMockData();
        }
    }

    // Setup theme based on Telegram theme
    setupTheme() {
        if (!this.tg) return;

        const themeParams = this.tg.themeParams;
        
        // Apply Telegram theme colors to game
        if (themeParams.bg_color) {
            document.documentElement.style.setProperty('--tg-bg-color', themeParams.bg_color);
        }
        
        if (themeParams.text_color) {
            document.documentElement.style.setProperty('--tg-text-color', themeParams.text_color);
        }
        
        if (themeParams.hint_color) {
            document.documentElement.style.setProperty('--tg-hint-color', themeParams.hint_color);
        }
        
        if (themeParams.button_color) {
            document.documentElement.style.setProperty('--tg-button-color', themeParams.button_color);
        }
    }

    // Setup main button for game actions
    setupMainButton() {
        if (!this.tg) return;

        this.tg.MainButton.setText('Play Game');
        this.tg.MainButton.color = '#2ea043';
        this.tg.MainButton.textColor = '#ffffff';
        
        this.tg.MainButton.onClick(() => {
            this.triggerHaptic('impact', 'medium');
            // Handle main button click based on current game state
            this.handleMainButtonClick();
        });
    }

    // Setup back button
    setupBackButton() {
        if (!this.tg) return;

        this.tg.BackButton.onClick(() => {
            this.triggerHaptic('impact', 'light');
            // Handle back navigation
            this.handleBackButton();
        });
    }

    // Setup haptic feedback
    setupHaptics() {
        if (!this.tg) return;

        // Enable haptic feedback for game events
        this.hapticEnabled = true;
    }

    // Setup viewport
    setupViewport() {
        if (!this.tg) return;

        // Handle viewport changes
        this.tg.onEvent('viewportChanged', () => {
            this.handleViewportChange();
        });
    }

    // Initialize mock data for development
    initMockData() {
        this.user = {
            id: 123456789,
            first_name: 'Test',
            last_name: 'User',
            username: 'testuser',
            language_code: 'en'
        };
        this.isInitialized = true;
        console.log('Using mock Telegram data for development');
    }

    // Get user information
    getUser() {
        return this.user;
    }

    // Authenticate user with backend
    async authenticateUser() {
        try {
            const userData = {
                telegramId: this.user?.id || 123456789,
                username: this.user?.username || 'anonymous',
                firstName: this.user?.first_name || 'Test',
                lastName: this.user?.last_name || 'User',
                languageCode: this.user?.language_code || 'en'
            };

            const response = await fetch(`${this.serverUrl}/api/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            const result = await response.json();
            
            if (result.success) {
                // Update game state with user data
                this.updateGameState(result.user);
                return result;
            } else {
                throw new Error(result.error || 'Authentication failed');
            }

        } catch (error) {
            console.error('Authentication error:', error);
            // Use offline mode
            return this.getOfflineUserData();
        }
    }

    // Update game state with user data
    updateGameState(userData) {
        gameState.player.level = userData.level || 1;
        gameState.player.experience = userData.experience || 0;
        gameState.player.soulCoins = userData.soulCoins || 100;
        gameState.player.hp = userData.hp || 100;
        gameState.player.energy = userData.energy || 100;
        gameState.player.lightLevel = userData.lightLevel || 50;
        gameState.player.inventory = userData.inventory || gameState.player.inventory;
        gameState.settings = userData.settings || gameState.settings;
    }

    // Get offline user data
    getOfflineUserData() {
        return {
            success: true,
            user: {
                telegramId: this.user?.id || 123456789,
                username: this.user?.username || 'anonymous',
                level: 1,
                experience: 0,
                soulCoins: 100,
                hp: 100,
                energy: 100,
                lightLevel: 50,
                inventory: gameState.player.inventory,
                settings: gameState.settings
            }
        };
    }

    // Show main button
    showMainButton(text = 'Play Game') {
        if (!this.tg) return;
        
        this.tg.MainButton.setText(text);
        this.tg.MainButton.show();
    }

    // Hide main button
    hideMainButton() {
        if (!this.tg) return;
        
        this.tg.MainButton.hide();
    }

    // Show back button
    showBackButton() {
        if (!this.tg) return;
        
        this.tg.BackButton.show();
    }

    // Hide back button
    hideBackButton() {
        if (!this.tg) return;
        
        this.tg.BackButton.hide();
    }

    // Trigger haptic feedback
    triggerHaptic(type = 'impact', style = 'light') {
        if (!this.tg || !this.hapticEnabled) return;

        try {
            switch (type) {
                case 'impact':
                    this.tg.HapticFeedback.impactOccurred(style); // light, medium, heavy
                    break;
                case 'notification':
                    this.tg.HapticFeedback.notificationOccurred(style); // error, success, warning
                    break;
                case 'selection':
                    this.tg.HapticFeedback.selectionChanged();
                    break;
            }
        } catch (error) {
            console.warn('Haptic feedback failed:', error);
        }
    }

    // Share game score
    shareScore(score, level) {
        if (!this.tg) {
            // Fallback sharing method
            this.fallbackShare(score, level);
            return;
        }

        const shareText = `🎮 I just scored ${score} points in Spiritual Shadow! 👻\nReached level ${level} in this dark fantasy adventure.\n\nCan you beat my score? Play now! 🔥`;
        
        try {
            // Use Telegram's sharing functionality
            this.tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(shareText)}`);
        } catch (error) {
            console.error('Share failed:', error);
            this.fallbackShare(score, level);
        }
    }

    // Fallback sharing method
    fallbackShare(score, level) {
        const shareText = `I scored ${score} points and reached level ${level} in Spiritual Shadow!`;
        
        if (navigator.share) {
            navigator.share({
                title: 'Spiritual Shadow',
                text: shareText,
                url: window.location.href
            });
        } else {
            // Copy to clipboard
            navigator.clipboard.writeText(`${shareText} ${window.location.href}`);
            alert('Score copied to clipboard!');
        }
    }

    // Invite friends
    inviteFriends() {
        if (!this.tg) {
            this.fallbackInvite();
            return;
        }

        const inviteText = `🎮 Join me in Spiritual Shadow! 👻\n\nA dark fantasy adventure where you battle spirits and solve ancient puzzles.\n\nPlay now and see if you can survive the cursed realm! 🔥`;
        
        try {
            this.tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(inviteText)}`);
        } catch (error) {
            console.error('Invite failed:', error);
            this.fallbackInvite();
        }
    }

    // Fallback invite method
    fallbackInvite() {
        const inviteText = `Join me in Spiritual Shadow - a dark fantasy adventure game!`;
        
        if (navigator.share) {
            navigator.share({
                title: 'Spiritual Shadow',
                text: inviteText,
                url: window.location.href
            });
        } else {
            navigator.clipboard.writeText(`${inviteText} ${window.location.href}`);
            alert('Invite link copied to clipboard!');
        }
    }

    // Handle main button clicks
    handleMainButtonClick() {
        // This will be called from game scenes
        if (window.currentScene) {
            window.currentScene.handleTelegramMainButton();
        }
    }

    // Handle back button
    handleBackButton() {
        // This will be called from game scenes
        if (window.currentScene) {
            window.currentScene.handleTelegramBackButton();
        }
    }

    // Handle viewport changes
    handleViewportChange() {
        // Adjust game layout if needed
        if (window.game && window.game.scale) {
            window.game.scale.refresh();
        }
    }

    // Send game data to backend
    async sendGameData(data) {
        try {
            const response = await fetch(`${this.serverUrl}/api/game/update`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    telegramId: this.user?.id,
                    ...data
                })
            });

            return await response.json();
        } catch (error) {
            console.error('Failed to send game data:', error);
            return { success: false, error: error.message };
        }
    }

    // Get leaderboard data
    async getLeaderboard(type = 'score', limit = 10) {
        try {
            const response = await fetch(`${this.serverUrl}/api/leaderboard?type=${type}&limit=${limit}`);
            const result = await response.json();
            
            return result.success ? result.leaderboard : [];
        } catch (error) {
            console.error('Failed to get leaderboard:', error);
            return [];
        }
    }

    // Close the mini app
    close() {
        if (this.tg) {
            this.tg.close();
        }
    }

    // Show alert
    showAlert(message) {
        if (this.tg) {
            this.tg.showAlert(message);
        } else {
            alert(message);
        }
    }

    // Show confirm dialog
    showConfirm(message, callback) {
        if (this.tg) {
            this.tg.showConfirm(message, callback);
        } else {
            const result = confirm(message);
            callback(result);
        }
    }

    // Show popup
    showPopup(params) {
        if (this.tg) {
            this.tg.showPopup(params);
        } else {
            alert(params.message || 'Popup');
        }
    }
}

// Initialize Telegram integration
const telegramIntegration = new TelegramIntegration();

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    telegramIntegration.init();
});

// Export for use in other files
window.telegramIntegration = telegramIntegration;

