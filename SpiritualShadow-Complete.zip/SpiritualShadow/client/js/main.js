// Spiritual Shadow - Main Game File
// Dark Fantasy 2D Game for Telegram Mini App

// Game configuration
const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    parent: 'game-container',
    backgroundColor: '#1a1a1a',
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        min: {
            width: 320,
            height: 240
        },
        max: {
            width: 1600,
            height: 1200
        }
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },
    scene: [LobbyScene, TutorialScene, GameScene, LeaderboardScene, ShopScene, SettingsScene]
};

// Global game state
const gameState = {
    player: {
        hp: 100,
        energy: 100,
        lightLevel: 50,
        level: 1,
        experience: 0,
        soulCoins: 0,
        inventory: {
            artifacts: [],
            spiritShards: 0,
            potions: 0,
            shadowFragments: 0
        }
    },
    settings: {
        soundEnabled: true,
        musicEnabled: true
    },
    currentLevel: 1,
    gameStarted: false
};

// Localization data
const localization = {
    en: {
        title: "Spiritual Shadow",
        play: "PLAY",
        settings: "Settings",
        shop: "Shop",
        leaderboard: "Leaderboard",
        withdraw: "Withdraw",
        dailyReward: "Daily Reward",
        hp: "HP",
        energy: "Energy",
        light: "Light",
        level: "Level",
        soulCoins: "Soul Coins",
        gameOver: "Game Over",
        victory: "Victory!",
        tutorial: "Tutorial",
        continue: "Continue",
        restart: "Restart",
        mainMenu: "Main Menu"
    }
};

// Current language
let currentLanguage = 'en';

// Get localized text
function getText(key) {
    return localization[currentLanguage][key] || key;
}

// Lobby Scene
class LobbyScene extends Phaser.Scene {
    constructor() {
        super({ key: 'LobbyScene' });
    }

    preload() {
        // Load assets
        this.load.image('lobbyBg', 'assets/images/lobby_background.png');
        this.load.image('playBtn', 'assets/images/play_button.png');
        this.load.image('settingsBtn', 'assets/images/settings_button.png');
        this.load.image('shopBtn', 'assets/images/shop_button.png');
        this.load.image('leaderboardBtn', 'assets/images/leaderboard_button.png');
        this.load.image('withdrawBtn', 'assets/images/withdraw_button.png');
        this.load.image('dailyRewardIcon', 'assets/images/daily_reward_icon.png');
        this.load.image('soundToggleOn', 'assets/images/sound_toggle_on.png');
        this.load.image('soundToggleOff', 'assets/images/sound_toggle_off.png');
        
        // Load player character
        this.load.image('player', 'assets/images/player_shadow_warrior.png');
        
        // Load background music
        this.load.audio('bgMusic', 'assets/music/background_music.wav');
    }

    create() {
        // Set current scene for Telegram integration
        window.currentScene = this;
        
        // Authenticate user with Telegram
        this.authenticateUser();
        
        // Background
        this.add.image(400, 300, 'lobbyBg').setDisplaySize(800, 600);

        // Title
        const title = this.add.text(400, 80, getText('title'), {
            fontSize: '48px',
            fill: '#8B4513',
            fontFamily: 'serif',
            stroke: '#000',
            strokeThickness: 3
        }).setOrigin(0.5);

        // Player character preview
        const playerPreview = this.add.image(200, 300, 'player').setScale(2);

        // Player stats display
        this.add.text(50, 400, `${getText('level')}: ${gameState.player.level}`, {
            fontSize: '20px',
            fill: '#FFF',
            fontFamily: 'serif'
        });

        this.add.text(50, 430, `${getText('soulCoins')}: ${gameState.player.soulCoins}`, {
            fontSize: '20px',
            fill: '#32CD32',
            fontFamily: 'serif'
        });

        // Buttons
        const playButton = this.add.image(500, 250, 'playBtn').setScale(1.5).setInteractive();
        playButton.on('pointerdown', () => {
            this.scene.start('GameScene');
        });

        const tutorialButton = this.add.image(500, 320, 'playBtn').setScale(1.2).setInteractive();
        tutorialButton.setTint(0x888888);
        tutorialButton.on('pointerdown', () => {
            this.scene.start('TutorialScene');
        });
        
        this.add.text(500, 320, getText('tutorial'), {
            fontSize: '16px',
            fill: '#FFF',
            fontFamily: 'serif'
        }).setOrigin(0.5);

        const settingsButton = this.add.image(450, 350, 'settingsBtn').setInteractive();
        settingsButton.on('pointerdown', () => {
            this.scene.start('SettingsScene');
        });

        const shopButton = this.add.image(550, 350, 'shopBtn').setInteractive();
        shopButton.on('pointerdown', () => {
            this.scene.start('ShopScene');
        });

        const leaderboardButton = this.add.image(450, 450, 'leaderboardBtn').setInteractive();
        leaderboardButton.on('pointerdown', () => {
            this.scene.start('LeaderboardScene');
        });

        const withdrawButton = this.add.image(550, 450, 'withdrawBtn').setInteractive();
        withdrawButton.on('pointerdown', () => {
            this.showWithdrawModal();
        });

        // Share score button
        const shareButton = this.add.text(650, 400, 'Share Score', {
            fontSize: '14px',
            fill: '#FFF',
            backgroundColor: '#0088cc',
            padding: { x: 10, y: 5 }
        }).setInteractive();
        
        shareButton.on('pointerdown', () => {
            if (window.telegramIntegration) {
                window.telegramIntegration.shareScore(gameState.player.experience, gameState.player.level);
            }
        });

        // Invite friends button
        const inviteButton = this.add.text(650, 450, 'Invite Friends', {
            fontSize: '14px',
            fill: '#FFF',
            backgroundColor: '#ff6b35',
            padding: { x: 10, y: 5 }
        }).setInteractive();
        
        inviteButton.on('pointerdown', () => {
            if (window.telegramIntegration) {
                window.telegramIntegration.inviteFriends();
            }
        });

        // Daily reward
        const dailyReward = this.add.image(700, 100, 'dailyRewardIcon').setScale(0.8).setInteractive();
        dailyReward.on('pointerdown', () => {
            this.showDailyReward();
        });

        // Sound toggle
        const soundToggle = this.add.image(750, 550, gameState.settings.soundEnabled ? 'soundToggleOn' : 'soundToggleOff')
            .setScale(0.8).setInteractive();
        soundToggle.on('pointerdown', () => {
            gameState.settings.soundEnabled = !gameState.settings.soundEnabled;
            soundToggle.setTexture(gameState.settings.soundEnabled ? 'soundToggleOn' : 'soundToggleOff');
        });

        // Start background music
        if (gameState.settings.musicEnabled && !this.bgMusic) {
            this.bgMusic = this.sound.add('bgMusic', { loop: true, volume: 0.3 });
            this.bgMusic.play();
        }

        // Show intro animation on first visit
        if (!gameState.gameStarted) {
            this.showIntroAnimation();
            gameState.gameStarted = true;
        }
        
        // Setup Telegram integration
        this.setupTelegramIntegration();
    }

    async authenticateUser() {
        if (window.telegramIntegration) {
            try {
                const result = await window.telegramIntegration.authenticateUser();
                if (result.success) {
                    console.log('User authenticated:', result.user);
                    // Update UI with user data
                    this.updateUserDisplay();
                }
            } catch (error) {
                console.error('Authentication failed:', error);
            }
        }
    }

    setupTelegramIntegration() {
        if (window.telegramIntegration) {
            // Show main button
            window.telegramIntegration.showMainButton('Play Game');
            
            // Hide back button in lobby
            window.telegramIntegration.hideBackButton();
        }
    }

    handleTelegramMainButton() {
        // Handle Telegram main button click
        window.telegramIntegration.triggerHaptic('impact', 'medium');
        this.scene.start('GameScene');
    }

    handleTelegramBackButton() {
        // Handle back button (not used in lobby)
    }

    updateUserDisplay() {
        // Update the player stats display with current data
        if (this.scene.isActive()) {
            this.scene.restart();
        }
    }

    showIntroAnimation() {
        // Fade in effect
        const overlay = this.add.rectangle(400, 300, 800, 600, 0x000000, 1);
        this.tweens.add({
            targets: overlay,
            alpha: 0,
            duration: 2000,
            ease: 'Power2'
        });

        // Title animation
        const titleText = this.add.text(400, 300, getText('title'), {
            fontSize: '64px',
            fill: '#8B4513',
            fontFamily: 'serif',
            stroke: '#000',
            strokeThickness: 4
        }).setOrigin(0.5).setAlpha(0);

        this.tweens.add({
            targets: titleText,
            alpha: 1,
            y: 80,
            duration: 3000,
            ease: 'Power2'
        });
    }

    showDailyReward() {
        // Simple daily reward popup
        const reward = Math.floor(Math.random() * 50) + 10;
        gameState.player.soulCoins += reward;
        
        const popup = this.add.rectangle(400, 300, 400, 200, 0x000000, 0.8);
        const popupText = this.add.text(400, 280, `${getText('dailyReward')}!`, {
            fontSize: '24px',
            fill: '#FFD700',
            fontFamily: 'serif'
        }).setOrigin(0.5);
        
        const rewardText = this.add.text(400, 320, `+${reward} ${getText('soulCoins')}`, {
            fontSize: '20px',
            fill: '#32CD32',
            fontFamily: 'serif'
        }).setOrigin(0.5);

        // Auto close after 3 seconds
        this.time.delayedCall(3000, () => {
            popup.destroy();
            popupText.destroy();
            rewardText.destroy();
        });
    }

    showWithdrawModal() {
        // Withdrawal simulation
        const popup = this.add.rectangle(400, 300, 500, 300, 0x000000, 0.9);
        const popupText = this.add.text(400, 250, `${getText('withdraw')} ${getText('soulCoins')}`, {
            fontSize: '24px',
            fill: '#FFF',
            fontFamily: 'serif'
        }).setOrigin(0.5);
        
        const balanceText = this.add.text(400, 290, `Balance: ${gameState.player.soulCoins}`, {
            fontSize: '18px',
            fill: '#32CD32',
            fontFamily: 'serif'
        }).setOrigin(0.5);

        const noteText = this.add.text(400, 330, 'Withdrawal simulation only', {
            fontSize: '14px',
            fill: '#888',
            fontFamily: 'serif'
        }).setOrigin(0.5);

        const closeBtn = this.add.text(400, 370, 'Close', {
            fontSize: '18px',
            fill: '#FFF',
            fontFamily: 'serif',
            backgroundColor: '#444',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setInteractive();

        closeBtn.on('pointerdown', () => {
            popup.destroy();
            popupText.destroy();
            balanceText.destroy();
            noteText.destroy();
            closeBtn.destroy();
        });
    }
}

// Game Scene
class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
    }

    preload() {
        // Load game assets
        this.load.image('cursedTile', 'assets/images/cursed_zone_tile.png');
        this.load.image('lightSource', 'assets/images/light_source_small.png');
        this.load.image('puzzleElement', 'assets/images/puzzle_element.png');
        this.load.image('spiritEnemy', 'assets/images/enemy_wandering_spirit.png');
        this.load.image('beastEnemy', 'assets/images/enemy_corrupted_beast.png');
        this.load.image('artifact', 'assets/images/artifact_icon.png');
        this.load.image('spiritShard', 'assets/images/spirit_shard_icon.png');
        this.load.image('potion', 'assets/images/potion_icon.png');
        this.load.image('shadowFragment', 'assets/images/shadow_fragment_icon.png');
        this.load.image('soulCoin', 'assets/images/soul_coin_icon.png');
    }

    create() {
        // Set current scene for Telegram integration
        window.currentScene = this;
        
        // Create game world
        this.createLevel();
        this.createPlayer();
        this.createEnemies();
        this.createUI();
        this.setupControls();
        
        // Game physics
        this.physics.world.setBounds(0, 0, 1600, 1200);
        this.cameras.main.setBounds(0, 0, 1600, 1200);
        this.cameras.main.startFollow(this.player);
        
        // Setup Telegram integration for game
        this.setupGameTelegramIntegration();
    }

    setupGameTelegramIntegration() {
        if (window.telegramIntegration) {
            // Show back button in game
            window.telegramIntegration.showBackButton();
            
            // Update main button for game actions
            window.telegramIntegration.showMainButton('Pause Game');
        }
    }

    handleTelegramMainButton() {
        // Handle pause/resume
        if (this.scene.isPaused()) {
            this.scene.resume();
            window.telegramIntegration.showMainButton('Pause Game');
        } else {
            this.scene.pause();
            window.telegramIntegration.showMainButton('Resume Game');
        }
    }

    handleTelegramBackButton() {
        // Go back to lobby
        window.telegramIntegration.triggerHaptic('impact', 'light');
        this.scene.start('LobbyScene');
    }

    createLevel() {
        // Create cursed zone tiles
        this.cursedZones = this.physics.add.staticGroup();
        for (let i = 0; i < 20; i++) {
            const x = Phaser.Math.Between(100, 1500);
            const y = Phaser.Math.Between(100, 1100);
            this.cursedZones.create(x, y, 'cursedTile');
        }

        // Create light sources
        this.lightSources = this.physics.add.staticGroup();
        for (let i = 0; i < 10; i++) {
            const x = Phaser.Math.Between(200, 1400);
            const y = Phaser.Math.Between(200, 1000);
            this.lightSources.create(x, y, 'lightSource');
        }

        // Create puzzle elements
        this.puzzleElements = this.physics.add.staticGroup();
        for (let i = 0; i < 5; i++) {
            const x = Phaser.Math.Between(300, 1300);
            const y = Phaser.Math.Between(300, 900);
            this.puzzleElements.create(x, y, 'puzzleElement');
        }

        // Create collectibles
        this.collectibles = this.physics.add.group();
        this.createCollectibles();
    }

    createCollectibles() {
        const collectibleTypes = ['artifact', 'spiritShard', 'potion', 'shadowFragment', 'soulCoin'];
        for (let i = 0; i < 15; i++) {
            const x = Phaser.Math.Between(100, 1500);
            const y = Phaser.Math.Between(100, 1100);
            const type = Phaser.Utils.Array.GetRandom(collectibleTypes);
            const collectible = this.collectibles.create(x, y, type);
            collectible.setData('type', type);
        }
    }

    createPlayer() {
        this.player = this.physics.add.sprite(400, 300, 'player');
        this.player.setCollideWorldBounds(true);
        this.player.setScale(1.5);
        
        // Player stats
        this.player.hp = gameState.player.hp;
        this.player.energy = gameState.player.energy;
        this.player.lightLevel = gameState.player.lightLevel;
    }

    createEnemies() {
        this.enemies = this.physics.add.group();
        
        // Create wandering spirits
        for (let i = 0; i < 8; i++) {
            const x = Phaser.Math.Between(100, 1500);
            const y = Phaser.Math.Between(100, 1100);
            const spirit = this.enemies.create(x, y, 'spiritEnemy');
            spirit.setData('type', 'spirit');
            spirit.setData('hp', 30);
            spirit.setVelocity(Phaser.Math.Between(-50, 50), Phaser.Math.Between(-50, 50));
        }

        // Create corrupted beasts
        for (let i = 0; i < 4; i++) {
            const x = Phaser.Math.Between(100, 1500);
            const y = Phaser.Math.Between(100, 1100);
            const beast = this.enemies.create(x, y, 'beastEnemy');
            beast.setData('type', 'beast');
            beast.setData('hp', 60);
            beast.setVelocity(Phaser.Math.Between(-30, 30), Phaser.Math.Between(-30, 30));
        }
    }

    createUI() {
        // Fixed UI elements
        this.uiContainer = this.add.container(0, 0).setScrollFactor(0);
        
        // HP Bar
        const hpBg = this.add.rectangle(100, 30, 200, 20, 0x800000);
        const hpBar = this.add.rectangle(100, 30, 200, 20, 0xFF0000);
        this.hpBar = hpBar;
        
        // Energy Bar
        const energyBg = this.add.rectangle(100, 60, 200, 20, 0x000080);
        const energyBar = this.add.rectangle(100, 60, 200, 20, 0x0000FF);
        this.energyBar = energyBar;
        
        // Light Level Bar
        const lightBg = this.add.rectangle(100, 90, 200, 20, 0x404040);
        const lightBar = this.add.rectangle(100, 90, 200, 20, 0xFFFF00);
        this.lightBar = lightBar;
        
        // Labels
        this.add.text(20, 20, getText('hp'), { fontSize: '16px', fill: '#FFF' }).setScrollFactor(0);
        this.add.text(20, 50, getText('energy'), { fontSize: '16px', fill: '#FFF' }).setScrollFactor(0);
        this.add.text(20, 80, getText('light'), { fontSize: '16px', fill: '#FFF' }).setScrollFactor(0);
        
        // Soul Coins counter
        this.soulCoinsText = this.add.text(600, 30, `${getText('soulCoins')}: ${gameState.player.soulCoins}`, {
            fontSize: '18px',
            fill: '#32CD32'
        }).setScrollFactor(0);

        // Back to lobby button
        const backBtn = this.add.text(700, 550, getText('mainMenu'), {
            fontSize: '16px',
            fill: '#FFF',
            backgroundColor: '#444',
            padding: { x: 10, y: 5 }
        }).setScrollFactor(0).setInteractive();
        
        backBtn.on('pointerdown', () => {
            this.scene.start('LobbyScene');
        });
    }

    setupControls() {
        // Keyboard controls
        this.cursors = this.input.keyboard.createCursorKeys();
        this.wasd = this.input.keyboard.addKeys('W,S,A,D');
        this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        
        // Touch controls for mobile
        this.input.on('pointerdown', (pointer) => {
            this.moveToPointer(pointer);
        });

        // Collision detection
        this.physics.add.overlap(this.player, this.collectibles, this.collectItem, null, this);
        this.physics.add.overlap(this.player, this.enemies, this.playerEnemyCollision, null, this);
        this.physics.add.overlap(this.player, this.lightSources, this.restoreLight, null, this);
        this.physics.add.overlap(this.player, this.cursedZones, this.enterCursedZone, null, this);
    }

    update() {
        // Player movement
        this.handlePlayerMovement();
        
        // Update UI
        this.updateUI();
        
        // Enemy AI
        this.updateEnemies();
        
        // Light level decay
        if (this.time.now % 1000 < 16) { // Every second
            gameState.player.lightLevel = Math.max(0, gameState.player.lightLevel - 1);
        }
    }

    handlePlayerMovement() {
        const speed = 200;
        
        if (this.cursors.left.isDown || this.wasd.A.isDown) {
            this.player.setVelocityX(-speed);
        } else if (this.cursors.right.isDown || this.wasd.D.isDown) {
            this.player.setVelocityX(speed);
        } else {
            this.player.setVelocityX(0);
        }
        
        if (this.cursors.up.isDown || this.wasd.W.isDown) {
            this.player.setVelocityY(-speed);
        } else if (this.cursors.down.isDown || this.wasd.S.isDown) {
            this.player.setVelocityY(speed);
        } else {
            this.player.setVelocityY(0);
        }
        
        // Attack
        if (this.spaceKey.isDown) {
            this.playerAttack();
        }
    }

    moveToPointer(pointer) {
        // Touch/click to move
        const distance = Phaser.Math.Distance.Between(this.player.x, this.player.y, pointer.worldX, pointer.worldY);
        if (distance > 50) {
            this.physics.moveToObject(this.player, pointer, 200);
        }
    }

    updateUI() {
        // Update health bar
        const hpPercent = gameState.player.hp / 100;
        this.hpBar.setScale(hpPercent, 1);
        
        // Update energy bar
        const energyPercent = gameState.player.energy / 100;
        this.energyBar.setScale(energyPercent, 1);
        
        // Update light bar
        const lightPercent = gameState.player.lightLevel / 100;
        this.lightBar.setScale(lightPercent, 1);
        
        // Update soul coins
        this.soulCoinsText.setText(`${getText('soulCoins')}: ${gameState.player.soulCoins}`);
    }

    updateEnemies() {
        this.enemies.children.entries.forEach(enemy => {
            // Simple AI: change direction randomly
            if (Math.random() < 0.01) {
                enemy.setVelocity(
                    Phaser.Math.Between(-50, 50),
                    Phaser.Math.Between(-50, 50)
                );
            }
            
            // Keep enemies in bounds
            if (enemy.x < 50 || enemy.x > 1550) enemy.setVelocityX(-enemy.body.velocity.x);
            if (enemy.y < 50 || enemy.y > 1150) enemy.setVelocityY(-enemy.body.velocity.y);
        });
    }

    collectItem(player, item) {
        const type = item.getData('type');
        
        switch (type) {
            case 'artifact':
                gameState.player.inventory.artifacts.push('Ancient Artifact');
                break;
            case 'spiritShard':
                gameState.player.inventory.spiritShards++;
                break;
            case 'potion':
                gameState.player.inventory.potions++;
                gameState.player.hp = Math.min(100, gameState.player.hp + 20);
                break;
            case 'shadowFragment':
                gameState.player.inventory.shadowFragments++;
                break;
            case 'soulCoin':
                gameState.player.soulCoins += Phaser.Math.Between(5, 15);
                break;
        }
        
        item.destroy();
    }

    playerEnemyCollision(player, enemy) {
        // Damage player
        gameState.player.hp -= 10;
        gameState.player.energy = Math.max(0, gameState.player.energy - 5);
        
        // Knockback effect
        const angle = Phaser.Math.Angle.Between(enemy.x, enemy.y, player.x, player.y);
        player.setVelocity(Math.cos(angle) * 300, Math.sin(angle) * 300);
        
        // Check game over
        if (gameState.player.hp <= 0) {
            this.gameOver();
        }
    }

    restoreLight(player, lightSource) {
        gameState.player.lightLevel = Math.min(100, gameState.player.lightLevel + 10);
        gameState.player.energy = Math.min(100, gameState.player.energy + 5);
    }

    enterCursedZone(player, cursedZone) {
        gameState.player.lightLevel = Math.max(0, gameState.player.lightLevel - 2);
        gameState.player.energy = Math.max(0, gameState.player.energy - 1);
    }

    playerAttack() {
        if (gameState.player.energy < 10) return;
        
        gameState.player.energy -= 10;
        
        // Find nearby enemies
        this.enemies.children.entries.forEach(enemy => {
            const distance = Phaser.Math.Distance.Between(this.player.x, this.player.y, enemy.x, enemy.y);
            if (distance < 100) {
                const enemyHp = enemy.getData('hp') - 20;
                enemy.setData('hp', enemyHp);
                
                if (enemyHp <= 0) {
                    gameState.player.soulCoins += 10;
                    enemy.destroy();
                }
            }
        });
    }

    gameOver() {
        // Game over screen
        const overlay = this.add.rectangle(400, 300, 800, 600, 0x000000, 0.8).setScrollFactor(0);
        const gameOverText = this.add.text(400, 250, getText('gameOver'), {
            fontSize: '48px',
            fill: '#FF0000',
            fontFamily: 'serif'
        }).setOrigin(0.5).setScrollFactor(0);
        
        const restartBtn = this.add.text(400, 350, getText('restart'), {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#444',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setScrollFactor(0).setInteractive();
        
        restartBtn.on('pointerdown', () => {
            // Reset player stats
            gameState.player.hp = 100;
            gameState.player.energy = 100;
            gameState.player.lightLevel = 50;
            this.scene.restart();
        });
        
        const menuBtn = this.add.text(400, 400, getText('mainMenu'), {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#444',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setScrollFactor(0).setInteractive();
        
        menuBtn.on('pointerdown', () => {
            this.scene.start('LobbyScene');
        });
    }
}

// Leaderboard Scene
class LeaderboardScene extends Phaser.Scene {
    constructor() {
        super({ key: 'LeaderboardScene' });
    }

    create() {
        this.add.rectangle(400, 300, 800, 600, 0x1a1a1a);
        
        const title = this.add.text(400, 50, getText('leaderboard'), {
            fontSize: '36px',
            fill: '#FFF',
            fontFamily: 'serif'
        }).setOrigin(0.5);
        
        // Mock leaderboard data
        const leaderboardData = [
            { name: 'ShadowMaster', score: 15420, level: 12 },
            { name: 'DarkWarrior', score: 12350, level: 10 },
            { name: 'SpiritHunter', score: 9870, level: 8 },
            { name: 'CursedSoul', score: 7650, level: 7 },
            { name: 'LightBringer', score: 5430, level: 5 }
        ];
        
        leaderboardData.forEach((entry, index) => {
            const y = 150 + (index * 60);
            this.add.text(100, y, `${index + 1}.`, { fontSize: '24px', fill: '#FFD700' });
            this.add.text(150, y, entry.name, { fontSize: '24px', fill: '#FFF' });
            this.add.text(400, y, `Level ${entry.level}`, { fontSize: '20px', fill: '#AAA' });
            this.add.text(600, y, `${entry.score} pts`, { fontSize: '20px', fill: '#32CD32' });
        });
        
        const backBtn = this.add.text(400, 500, getText('mainMenu'), {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#444',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setInteractive();
        
        backBtn.on('pointerdown', () => {
            this.scene.start('LobbyScene');
        });
    }
}

// Shop Scene
class ShopScene extends Phaser.Scene {
    constructor() {
        super({ key: 'ShopScene' });
    }

    create() {
        this.add.rectangle(400, 300, 800, 600, 0x1a1a1a);
        
        const title = this.add.text(400, 50, getText('shop'), {
            fontSize: '36px',
            fill: '#FFF',
            fontFamily: 'serif'
        }).setOrigin(0.5);
        
        // Shop items
        const shopItems = [
            { name: 'Health Potion', price: 50, icon: 'potion' },
            { name: 'Spirit Shard', price: 100, icon: 'spiritShard' },
            { name: 'Shadow Fragment', price: 200, icon: 'shadowFragment' },
            { name: 'Ancient Artifact', price: 500, icon: 'artifact' }
        ];
        
        shopItems.forEach((item, index) => {
            const y = 150 + (index * 80);
            this.add.image(100, y, item.icon).setScale(0.8);
            this.add.text(150, y - 10, item.name, { fontSize: '20px', fill: '#FFF' });
            this.add.text(150, y + 15, `${item.price} Soul Coins`, { fontSize: '16px', fill: '#32CD32' });
            
            const buyBtn = this.add.text(600, y, 'Buy', {
                fontSize: '18px',
                fill: '#FFF',
                backgroundColor: '#006600',
                padding: { x: 15, y: 8 }
            }).setInteractive();
            
            buyBtn.on('pointerdown', () => {
                if (gameState.player.soulCoins >= item.price) {
                    gameState.player.soulCoins -= item.price;
                    // Add item to inventory logic here
                    buyBtn.setText('Bought!').setStyle({ backgroundColor: '#666' });
                    buyBtn.removeInteractive();
                }
            });
        });
        
        // Current balance
        this.add.text(400, 480, `${getText('soulCoins')}: ${gameState.player.soulCoins}`, {
            fontSize: '24px',
            fill: '#32CD32',
            fontFamily: 'serif'
        }).setOrigin(0.5);
        
        const backBtn = this.add.text(400, 530, getText('mainMenu'), {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#444',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setInteractive();
        
        backBtn.on('pointerdown', () => {
            this.scene.start('LobbyScene');
        });
    }
}

// Settings Scene
class SettingsScene extends Phaser.Scene {
    constructor() {
        super({ key: 'SettingsScene' });
    }

    create() {
        this.add.rectangle(400, 300, 800, 600, 0x1a1a1a);
        
        const title = this.add.text(400, 50, getText('settings'), {
            fontSize: '36px',
            fill: '#FFF',
            fontFamily: 'serif'
        }).setOrigin(0.5);
        
        // Sound settings
        this.add.text(200, 200, 'Sound Effects:', { fontSize: '24px', fill: '#FFF' });
        const soundToggle = this.add.image(500, 200, gameState.settings.soundEnabled ? 'soundToggleOn' : 'soundToggleOff')
            .setInteractive();
        soundToggle.on('pointerdown', () => {
            gameState.settings.soundEnabled = !gameState.settings.soundEnabled;
            soundToggle.setTexture(gameState.settings.soundEnabled ? 'soundToggleOn' : 'soundToggleOff');
        });
        
        // Music settings
        this.add.text(200, 280, 'Background Music:', { fontSize: '24px', fill: '#FFF' });
        const musicToggle = this.add.image(500, 280, gameState.settings.musicEnabled ? 'soundToggleOn' : 'soundToggleOff')
            .setInteractive();
        musicToggle.on('pointerdown', () => {
            gameState.settings.musicEnabled = !gameState.settings.musicEnabled;
            musicToggle.setTexture(gameState.settings.musicEnabled ? 'soundToggleOn' : 'soundToggleOff');
        });
        
        const backBtn = this.add.text(400, 450, getText('mainMenu'), {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#444',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setInteractive();
        
        backBtn.on('pointerdown', () => {
            this.scene.start('LobbyScene');
        });
    }
}

// Initialize the game
const game = new Phaser.Game(config);

// Telegram Mini App integration placeholder
if (window.Telegram && window.Telegram.WebApp) {
    window.Telegram.WebApp.ready();
    window.Telegram.WebApp.expand();
}

