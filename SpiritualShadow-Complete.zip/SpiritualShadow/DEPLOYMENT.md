# Spiritual Shadow - Deployment Guide 🚀

This guide covers different deployment options for the Spiritual Shadow game.

## 📋 Prerequisites

- Node.js 16+ and npm
- Firebase project configured
- Domain with HTTPS (required for Telegram Mini App)
- Telegram Bot Token

## 🌐 Client-Only Deployment (Static Hosting)

### Option 1: Netlify
1. Fork/clone the repository
2. Connect your GitHub repo to Netlify
3. Set build directory to `client`
4. Deploy automatically on push

### Option 2: Vercel
1. Install Vercel CLI: `npm i -g vercel`
2. Navigate to project root
3. Run: `vercel --prod`
4. Set output directory to `client`

### Option 3: Firebase Hosting
1. Install Firebase CLI: `npm i -g firebase-tools`
2. Login: `firebase login`
3. Initialize: `firebase init hosting`
4. Set public directory to `client`
5. Deploy: `firebase deploy`

### Option 4: GitHub Pages
1. Push code to GitHub repository
2. Go to Settings > Pages
3. Select source branch and `/client` folder
4. Access via `https://username.github.io/spiritual-shadow`

## 🖥️ Full Stack Deployment

### Option 1: Railway
1. Connect GitHub repository to Railway
2. Create new project from repo
3. Railway will auto-detect Node.js
4. Set start command: `cd server && npm start`
5. Add environment variables in Railway dashboard

### Option 2: Heroku
1. Install Heroku CLI
2. Create Heroku app: `heroku create spiritual-shadow-api`
3. Set buildpack: `heroku buildpacks:set heroku/nodejs`
4. Configure environment variables:
   ```bash
   heroku config:set NODE_ENV=production
   heroku config:set FIREBASE_PRIVATE_KEY="your-key"
   # Add other Firebase config vars
   ```
5. Deploy: `git push heroku main`

### Option 3: DigitalOcean App Platform
1. Connect GitHub repository
2. Select Node.js environment
3. Set build command: `cd server && npm install`
4. Set run command: `cd server && npm start`
5. Configure environment variables

### Option 4: AWS Elastic Beanstalk
1. Install EB CLI
2. Initialize: `eb init`
3. Create environment: `eb create production`
4. Deploy: `eb deploy`

## 🔥 Firebase Configuration

### 1. Create Firebase Project
```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login to Firebase
firebase login

# Initialize project
firebase init
```

### 2. Configure Firestore
1. Go to Firebase Console
2. Create Firestore database
3. Set security rules:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /leaderboard/{document} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

### 3. Configure Realtime Database
1. Create Realtime Database
2. Set security rules:
```json
{
  "rules": {
    "gameSessions": {
      "$sessionId": {
        ".read": "auth != null",
        ".write": "auth != null"
      }
    }
  }
}
```

### 4. Generate Service Account
1. Go to Project Settings > Service Accounts
2. Generate new private key
3. Download JSON file
4. Extract credentials for environment variables

## 📱 Telegram Mini App Setup

### 1. Create Telegram Bot
1. Message @BotFather on Telegram
2. Create new bot: `/newbot`
3. Set bot name and username
4. Save the bot token

### 2. Configure Mini App
1. Set Mini App URL: `/newapp`
2. Select your bot
3. Enter app name and description
4. Set Web App URL to your deployed domain
5. Upload app icon (512x512 PNG)

### 3. Configure Domain
```bash
# Set domain for Mini App
/setdomain
# Select your bot
# Enter your HTTPS domain
```

### 4. Test Mini App
1. Open your bot in Telegram
2. Use `/start` command
3. Click "Play Game" button
4. Verify all features work correctly

## 🔧 Environment Variables

### Server Environment Variables
Create `.env` file in server directory:

```env
# Server Configuration
PORT=3000
NODE_ENV=production

# Firebase Configuration
FIREBASE_PRIVATE_KEY_ID=your_private_key_id
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nyour_private_key\n-----END PRIVATE KEY-----\n"
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-xxxxx@spiritual-shadow.iam.gserviceaccount.com
FIREBASE_CLIENT_ID=your_client_id
FIREBASE_CLIENT_CERT_URL=https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-xxxxx%40spiritual-shadow.iam.gserviceaccount.com

# Telegram Configuration
TELEGRAM_BOT_TOKEN=your_bot_token_here

# Security
JWT_SECRET=your_jwt_secret_here
```

### Client Configuration
Update `client/js/telegramIntegration.js`:

```javascript
// Change server URL for production
this.serverUrl = 'https://your-api-domain.com';
```

## 🔒 Security Considerations

### 1. HTTPS Required
- Telegram Mini Apps require HTTPS
- Use SSL certificate from Let's Encrypt or your hosting provider
- Ensure all API calls use HTTPS

### 2. Environment Variables
- Never commit `.env` files to version control
- Use platform-specific environment variable management
- Rotate secrets regularly

### 3. Firebase Security
- Configure proper Firestore security rules
- Use Firebase Authentication for user verification
- Limit API access to authenticated users only

### 4. CORS Configuration
```javascript
// Allow only your domain in production
app.use(cors({
    origin: ['https://your-domain.com', 'https://your-api-domain.com'],
    credentials: true
}));
```

## 📊 Monitoring & Analytics

### 1. Firebase Analytics
```javascript
// Add to client/js/main.js
import { getAnalytics, logEvent } from 'firebase/analytics';

const analytics = getAnalytics();
logEvent(analytics, 'game_start');
```

### 2. Error Tracking
```javascript
// Add error tracking
window.addEventListener('error', (event) => {
    console.error('Game error:', event.error);
    // Send to error tracking service
});
```

### 3. Performance Monitoring
```javascript
// Monitor game performance
const startTime = performance.now();
// ... game logic
const endTime = performance.now();
console.log(`Game loop took ${endTime - startTime} milliseconds`);
```

## 🧪 Testing Deployment

### 1. Local Testing
```bash
# Test client locally
cd client
python -m http.server 8000

# Test server locally
cd server
npm start
```

### 2. Production Testing
1. Test all game features
2. Verify Telegram integration
3. Check mobile responsiveness
4. Test different browsers
5. Verify Firebase connectivity

### 3. Load Testing
```bash
# Install artillery for load testing
npm install -g artillery

# Create test script
artillery quick --count 10 --num 5 https://your-api-domain.com/health
```

## 🔄 CI/CD Pipeline

### GitHub Actions Example
Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy Spiritual Shadow

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '16'
        
    - name: Install dependencies
      run: cd server && npm install
      
    - name: Run tests
      run: cd server && npm test
      
    - name: Deploy to production
      run: |
        # Add your deployment commands here
        echo "Deploying to production..."
```

## 📝 Post-Deployment Checklist

- [ ] Game loads correctly on HTTPS
- [ ] Telegram Mini App integration works
- [ ] Firebase authentication functions
- [ ] Leaderboard updates properly
- [ ] Share functionality works
- [ ] Mobile responsiveness verified
- [ ] All assets load correctly
- [ ] Error tracking configured
- [ ] Performance monitoring active
- [ ] Backup strategy implemented

## 🆘 Troubleshooting

### Common Deployment Issues

**CORS Errors:**
- Check server CORS configuration
- Verify client domain is allowed
- Ensure HTTPS is used

**Firebase Connection Issues:**
- Verify service account credentials
- Check Firebase project configuration
- Ensure proper security rules

**Telegram Integration Problems:**
- Verify HTTPS domain
- Check bot configuration
- Test Mini App URL

**Asset Loading Issues:**
- Check file paths are correct
- Verify HTTPS for all assets
- Test on different devices

---

🎮 **Happy Deploying!** Your Spiritual Shadow game is ready to haunt the digital realm! 👻

