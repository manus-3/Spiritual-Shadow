// Firebase Admin SDK Configuration for Spiritual Shadow
const admin = require('firebase-admin');

// Service account configuration
const serviceAccount = {
  "type": "service_account",
  "project_id": "spiritual-shadow",
  "private_key_id": process.env.FIREBASE_PRIVATE_KEY_ID,
  "private_key": process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  "client_email": process.env.FIREBASE_CLIENT_EMAIL,
  "client_id": process.env.FIREBASE_CLIENT_ID,
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": process.env.FIREBASE_CLIENT_CERT_URL
};

// Initialize Firebase Admin
let firebaseApp;
try {
  firebaseApp = admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://spiritual-shadow-default-rtdb.firebaseio.com",
    storageBucket: "spiritual-shadow.appspot.com"
  });
  console.log('Firebase Admin SDK initialized successfully');
} catch (error) {
  console.error('Firebase Admin SDK initialization failed:', error);
}

// Export Firebase services
const db = admin.firestore();
const realtimeDb = admin.database();
const auth = admin.auth();
const storage = admin.storage();

// Firestore collections
const collections = {
  users: 'users',
  gameSessions: 'gameSessions',
  leaderboard: 'leaderboard',
  shopItems: 'shopItems',
  gameConfig: 'gameConfig'
};

// Helper functions
const helpers = {
  // Get user by Telegram ID
  async getUserByTelegramId(telegramId) {
    try {
      const doc = await db.collection(collections.users).doc(telegramId.toString()).get();
      return doc.exists ? { id: doc.id, ...doc.data() } : null;
    } catch (error) {
      console.error('Error getting user:', error);
      return null;
    }
  },

  // Create or update user
  async createOrUpdateUser(telegramId, userData) {
    try {
      const userRef = db.collection(collections.users).doc(telegramId.toString());
      await userRef.set(userData, { merge: true });
      return true;
    } catch (error) {
      console.error('Error creating/updating user:', error);
      return false;
    }
  },

  // Get leaderboard
  async getLeaderboard(orderBy = 'experience', limit = 10) {
    try {
      const snapshot = await db.collection(collections.users)
        .orderBy(orderBy, 'desc')
        .limit(limit)
        .get();
      
      const leaderboard = [];
      snapshot.forEach(doc => {
        leaderboard.push({ id: doc.id, ...doc.data() });
      });
      
      return leaderboard;
    } catch (error) {
      console.error('Error getting leaderboard:', error);
      return [];
    }
  },

  // Save game session
  async saveGameSession(sessionData) {
    try {
      const sessionRef = realtimeDb.ref(`gameSessions/${sessionData.sessionId}`);
      await sessionRef.set(sessionData);
      return true;
    } catch (error) {
      console.error('Error saving game session:', error);
      return false;
    }
  },

  // Update game session
  async updateGameSession(sessionId, updates) {
    try {
      const sessionRef = realtimeDb.ref(`gameSessions/${sessionId}`);
      await sessionRef.update(updates);
      return true;
    } catch (error) {
      console.error('Error updating game session:', error);
      return false;
    }
  },

  // Get game configuration
  async getGameConfig() {
    try {
      const doc = await db.collection(collections.gameConfig).doc('main').get();
      return doc.exists ? doc.data() : null;
    } catch (error) {
      console.error('Error getting game config:', error);
      return null;
    }
  },

  // Verify Telegram user
  async verifyTelegramUser(initData) {
    // Implement Telegram Mini App user verification
    // This would validate the initData from Telegram
    try {
      // Parse and verify the initData
      // Return user data if valid
      return { valid: true, user: null };
    } catch (error) {
      console.error('Error verifying Telegram user:', error);
      return { valid: false, user: null };
    }
  }
};

module.exports = {
  admin,
  db,
  realtimeDb,
  auth,
  storage,
  collections,
  helpers
};

