// Firebase configuration for Spiritual Shadow
const firebaseConfig = {
  apiKey: "AIzaSyAXgSGleDzngVCD2R-LzJfzACPoYx6xnpk",
  authDomain: "spiritual-shadow.firebaseapp.com",
  databaseURL: "https://spiritual-shadow-default-rtdb.firebaseio.com",
  projectId: "spiritual-shadow",
  storageBucket: "spiritual-shadow.appspot.com",
  messagingSenderId: "905075250044",
  appId: "1:905075250044:web:abc123def456ghi789"
};

// Initialize Firebase
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getDatabase } from 'firebase/database';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const realtimeDb = getDatabase(app);

export default app;

