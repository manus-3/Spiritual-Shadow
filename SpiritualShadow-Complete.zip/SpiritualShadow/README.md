# Spiritual Shadow 👻

A dark fantasy 2D action-adventure game designed for Telegram Mini App platform. Battle spirits, solve ancient puzzles, and survive in a cursed realm filled with shadows and mysteries.

## 🎮 Game Features

### Core Gameplay
- **Character System**: Customizable shadow warrior with HP, energy, and light level management
- **Combat System**: Tap-to-attack mechanics with dodge abilities and special spirit powers
- **Light Management**: Strategic light source usage to survive in the cursed realm
- **Puzzle Elements**: Ancient mechanisms and spirit puzzles to solve
- **Enemy AI**: Wandering spirits and corrupted beasts with different behaviors

### Game Modes
- **Tutorial Level**: Learn the basics of survival and combat
- **Campaign Mode**: Progress through 3+ challenging levels
- **Survival Mode**: Test your endurance against endless waves

### Social Features
- **Leaderboard System**: Global and friends-only rankings
- **Score Sharing**: Share achievements on Telegram
- **Friend Invites**: Invite friends to play via Telegram
- **Daily Rewards**: Login bonuses and special events

### Progression System
- **Soul Coins**: In-game currency earned through gameplay
- **Experience Points**: Level up your character
- **Inventory System**: Collect artifacts, spirit shards, and potions
- **Shop System**: Purchase upgrades and items
- **Withdrawal System**: Simulated cryptocurrency withdrawal (demo only)

## 🛠️ Technical Stack

### Frontend
- **Phaser.js 3.55.2**: Game engine for 2D graphics and physics
- **HTML5 Canvas**: Rendering and graphics
- **Tailwind CSS**: UI styling and responsive design
- **Telegram Mini App SDK**: Platform integration

### Backend
- **Node.js + Express**: RESTful API server
- **Firebase**: Authentication and real-time database
- **CORS**: Cross-origin resource sharing support

### Assets
- **Pixel Art Graphics**: Custom dark fantasy themed sprites
- **Ambient Music**: Atmospheric background soundtrack
- **Sound Effects**: Combat and interaction audio
- **Localization**: Multi-language support (EN, ES, RU)

## 📁 Project Structure

```
SpiritualShadow/
├── client/                 # Frontend game files
│   ├── index.html         # Main HTML file
│   ├── js/                # JavaScript game logic
│   │   ├── main.js        # Core game scenes
│   │   ├── gameLogic.js   # Advanced game mechanics
│   │   ├── tutorial.js    # Tutorial implementation
│   │   └── telegramIntegration.js # Telegram Mini App integration
│   └── assets/            # Game assets
│       ├── images/        # Sprite graphics
│       ├── music/         # Background music
│       ├── sounds/        # Sound effects
│       └── data/          # Localization and config
├── server/                # Backend API server
│   ├── server.js          # Main server file
│   ├── package.json       # Dependencies
│   └── .env.example       # Environment variables template
└── firebase-config/       # Firebase configuration
    ├── firebase-config.js # Client-side config
    └── firebase-admin-config.js # Server-side config
```

## 🚀 Installation & Setup

### Prerequisites
- Node.js 16+ and npm
- Firebase project with Firestore and Realtime Database
- Telegram Bot Token (for Mini App)

### Client Setup
1. Open `client/index.html` in a web browser
2. Or serve via a local web server:
   ```bash
   cd client
   python -m http.server 8000
   # Visit http://localhost:8000
   ```

### Server Setup
1. Install dependencies:
   ```bash
   cd server
   npm install
   ```

2. Configure environment variables:
   ```bash
   cp .env.example .env
   # Edit .env with your Firebase credentials
   ```

3. Start the server:
   ```bash
   npm start
   # Server runs on http://localhost:3000
   ```

### Firebase Configuration
1. Create a Firebase project at https://console.firebase.google.com
2. Enable Firestore and Realtime Database
3. Generate service account credentials
4. Update configuration files with your project details

### Telegram Mini App Setup
1. Create a bot via @BotFather on Telegram
2. Set up Mini App with your domain
3. Configure webhook URL if needed
4. Test in Telegram Web or mobile app

## 🎯 Game Controls

### Desktop
- **WASD / Arrow Keys**: Move character
- **Spacebar**: Attack enemies
- **Mouse Click**: Interact with objects and UI

### Mobile/Touch
- **Tap to Move**: Touch screen to move character
- **Tap to Attack**: Tap near enemies to attack
- **Touch UI**: Interact with buttons and menus

### Telegram Integration
- **Main Button**: Context-sensitive actions (Play, Pause, etc.)
- **Back Button**: Navigate to previous screen
- **Haptic Feedback**: Tactile responses for actions

## 🏆 Gameplay Guide

### Getting Started
1. Complete the tutorial to learn basic mechanics
2. Manage your light level - it decreases over time
3. Find light sources to restore energy and light
4. Avoid cursed zones that drain your resources

### Combat Tips
- Attack costs energy - manage it wisely
- Different enemies have unique behaviors
- Use light strategically to reveal hidden paths
- Collect spirit shards to unlock special abilities

### Progression Strategy
- Complete daily challenges for bonus rewards
- Solve puzzles for valuable items and experience
- Collect soul coins to purchase upgrades
- Share scores to compete with friends

## 🔧 Configuration

### Game Settings
- Sound effects and music toggle
- Language selection (English, Spanish, Russian)
- Graphics quality options
- Control sensitivity

### Localization
Edit `client/assets/data/localization.json` to add new languages or modify text:

```json
{
  "en": {
    "title": "Spiritual Shadow",
    "play": "PLAY",
    "settings": "Settings"
  }
}
```

## 🚀 Deployment

### Static Hosting (Client Only)
Deploy the `client/` folder to any static hosting service:
- GitHub Pages
- Netlify
- Vercel
- Firebase Hosting

### Full Stack Deployment
1. Deploy server to cloud platform (Heroku, Railway, etc.)
2. Update client configuration with server URL
3. Configure Firebase for production
4. Set up domain and SSL certificate

### Telegram Mini App Deployment
1. Host the game on HTTPS domain
2. Register domain with @BotFather
3. Configure Mini App settings
4. Test in Telegram environment

## 🐛 Troubleshooting

### Common Issues

**Game not loading:**
- Check browser console for errors
- Ensure all assets are properly loaded
- Verify HTTPS for Telegram Mini App

**Server connection failed:**
- Check server is running on correct port
- Verify CORS configuration
- Check Firebase credentials

**Telegram integration not working:**
- Ensure Telegram SDK is loaded
- Check Mini App configuration
- Verify domain is registered with Telegram

### Debug Mode
Enable debug mode by adding `?debug=true` to URL:
- Shows physics bodies and collision boxes
- Displays performance metrics
- Enables console logging

## 📄 License

This project is created for educational and demonstration purposes. All assets and code are provided as-is for learning game development with Telegram Mini Apps.

## 🤝 Contributing

This is a demonstration project, but feel free to:
- Report bugs or issues
- Suggest improvements
- Fork and create your own version
- Use as a learning resource

## 📞 Support

For questions or issues:
- Check the troubleshooting section
- Review the code comments
- Test in different browsers/devices
- Verify all dependencies are installed

---

**Spiritual Shadow** - Enter the realm of shadows and test your survival skills! 👻⚔️

