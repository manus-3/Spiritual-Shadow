// Spiritual Shadow - Backend Server
// Node.js + Express + Firebase

const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// Firebase Admin SDK initialization
const serviceAccount = {
    type: "service_account",
    project_id: "spiritual-shadow",
    private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID,
    private_key: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    client_email: process.env.FIREBASE_CLIENT_EMAIL,
    client_id: process.env.FIREBASE_CLIENT_ID,
    auth_uri: "https://accounts.google.com/o/oauth2/auth",
    token_uri: "https://oauth2.googleapis.com/token",
    auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    client_x509_cert_url: process.env.FIREBASE_CLIENT_CERT_URL
};

// Initialize Firebase Admin (with fallback for development)
try {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        databaseURL: "https://spiritual-shadow-default-rtdb.firebaseio.com"
    });
    console.log('Firebase Admin initialized successfully');
} catch (error) {
    console.log('Firebase Admin initialization failed, using mock data:', error.message);
}

const db = admin.firestore();
const realtimeDb = admin.database();

// Mock data for development
const mockUsers = new Map();
const mockLeaderboard = [
    { id: '1', name: 'ShadowMaster', score: 15420, level: 12, soulCoins: 2500 },
    { id: '2', name: 'DarkWarrior', score: 12350, level: 10, soulCoins: 1800 },
    { id: '3', name: 'SpiritHunter', score: 9870, level: 8, soulCoins: 1200 },
    { id: '4', name: 'CursedSoul', score: 7650, level: 7, soulCoins: 950 },
    { id: '5', name: 'LightBringer', score: 5430, level: 5, soulCoins: 650 }
];

// Routes

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// User authentication and profile
app.post('/api/auth/login', async (req, res) => {
    try {
        const { telegramId, username, firstName, lastName } = req.body;
        
        if (!telegramId) {
            return res.status(400).json({ error: 'Telegram ID is required' });
        }

        // Check if user exists
        let userData = mockUsers.get(telegramId) || {
            telegramId,
            username: username || 'Anonymous',
            firstName: firstName || '',
            lastName: lastName || '',
            level: 1,
            experience: 0,
            soulCoins: 100,
            hp: 100,
            energy: 100,
            lightLevel: 50,
            inventory: {
                artifacts: [],
                spiritShards: 0,
                potions: 3,
                shadowFragments: 0
            },
            stats: {
                gamesPlayed: 0,
                enemiesDefeated: 0,
                levelsCompleted: 0,
                totalPlayTime: 0
            },
            settings: {
                soundEnabled: true,
                musicEnabled: true,
                language: 'en'
            },
            lastLogin: new Date().toISOString(),
            createdAt: mockUsers.has(telegramId) ? mockUsers.get(telegramId).createdAt : new Date().toISOString()
        };

        // Update last login
        userData.lastLogin = new Date().toISOString();
        mockUsers.set(telegramId, userData);

        // In production, save to Firebase
        try {
            await db.collection('users').doc(telegramId.toString()).set(userData, { merge: true });
        } catch (firebaseError) {
            console.log('Firebase save failed, using mock data');
        }

        res.json({
            success: true,
            user: userData,
            token: `mock_token_${telegramId}`
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get user profile
app.get('/api/user/:telegramId', async (req, res) => {
    try {
        const { telegramId } = req.params;
        
        let userData = mockUsers.get(telegramId);
        
        if (!userData) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({ success: true, user: userData });

    } catch (error) {
        console.error('Get user error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Update user profile
app.put('/api/user/:telegramId', async (req, res) => {
    try {
        const { telegramId } = req.params;
        const updates = req.body;
        
        let userData = mockUsers.get(telegramId);
        
        if (!userData) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Merge updates
        userData = { ...userData, ...updates, updatedAt: new Date().toISOString() };
        mockUsers.set(telegramId, userData);

        // In production, save to Firebase
        try {
            await db.collection('users').doc(telegramId.toString()).update(updates);
        } catch (firebaseError) {
            console.log('Firebase update failed, using mock data');
        }

        res.json({ success: true, user: userData });

    } catch (error) {
        console.error('Update user error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Leaderboard
app.get('/api/leaderboard', async (req, res) => {
    try {
        const { type = 'score', limit = 10 } = req.query;
        
        let leaderboard = [...mockLeaderboard];
        
        // Add current users to leaderboard
        for (let [telegramId, userData] of mockUsers) {
            if (!leaderboard.find(entry => entry.id === telegramId)) {
                leaderboard.push({
                    id: telegramId,
                    name: userData.username,
                    score: userData.experience,
                    level: userData.level,
                    soulCoins: userData.soulCoins
                });
            }
        }

        // Sort by type
        if (type === 'level') {
            leaderboard.sort((a, b) => b.level - a.level);
        } else if (type === 'soulCoins') {
            leaderboard.sort((a, b) => b.soulCoins - a.soulCoins);
        } else {
            leaderboard.sort((a, b) => b.score - a.score);
        }

        // Limit results
        leaderboard = leaderboard.slice(0, parseInt(limit));

        res.json({ success: true, leaderboard });

    } catch (error) {
        console.error('Leaderboard error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Game session
app.post('/api/game/start', async (req, res) => {
    try {
        const { telegramId, level = 1 } = req.body;
        
        const sessionId = `session_${telegramId}_${Date.now()}`;
        const gameSession = {
            sessionId,
            telegramId,
            level,
            startTime: new Date().toISOString(),
            status: 'active',
            score: 0,
            enemiesDefeated: 0,
            itemsCollected: 0
        };

        // In production, save to Firebase Realtime Database
        try {
            await realtimeDb.ref(`gameSessions/${sessionId}`).set(gameSession);
        } catch (firebaseError) {
            console.log('Firebase session save failed');
        }

        res.json({ success: true, session: gameSession });

    } catch (error) {
        console.error('Start game error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// End game session
app.post('/api/game/end', async (req, res) => {
    try {
        const { sessionId, telegramId, score, enemiesDefeated, itemsCollected, completed } = req.body;
        
        // Update user stats
        let userData = mockUsers.get(telegramId);
        if (userData) {
            userData.experience += score;
            userData.stats.gamesPlayed += 1;
            userData.stats.enemiesDefeated += enemiesDefeated;
            if (completed) {
                userData.stats.levelsCompleted += 1;
                userData.level = Math.max(userData.level, userData.stats.levelsCompleted);
            }
            mockUsers.set(telegramId, userData);
        }

        // Update session
        const sessionUpdate = {
            endTime: new Date().toISOString(),
            status: completed ? 'completed' : 'failed',
            score,
            enemiesDefeated,
            itemsCollected
        };

        // In production, update Firebase
        try {
            await realtimeDb.ref(`gameSessions/${sessionId}`).update(sessionUpdate);
            if (userData) {
                await db.collection('users').doc(telegramId.toString()).update(userData);
            }
        } catch (firebaseError) {
            console.log('Firebase update failed');
        }

        res.json({ success: true, session: sessionUpdate, user: userData });

    } catch (error) {
        console.error('End game error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Daily reward
app.post('/api/daily-reward/:telegramId', async (req, res) => {
    try {
        const { telegramId } = req.params;
        
        let userData = mockUsers.get(telegramId);
        if (!userData) {
            return res.status(404).json({ error: 'User not found' });
        }

        const today = new Date().toDateString();
        const lastReward = userData.lastDailyReward;

        if (lastReward === today) {
            return res.status(400).json({ error: 'Daily reward already claimed today' });
        }

        // Calculate reward
        const baseReward = 50;
        const levelBonus = userData.level * 10;
        const totalReward = baseReward + levelBonus;

        // Update user
        userData.soulCoins += totalReward;
        userData.lastDailyReward = today;
        mockUsers.set(telegramId, userData);

        // In production, save to Firebase
        try {
            await db.collection('users').doc(telegramId.toString()).update({
                soulCoins: userData.soulCoins,
                lastDailyReward: today
            });
        } catch (firebaseError) {
            console.log('Firebase update failed');
        }

        res.json({ 
            success: true, 
            reward: totalReward,
            newBalance: userData.soulCoins
        });

    } catch (error) {
        console.error('Daily reward error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Shop purchase
app.post('/api/shop/purchase', async (req, res) => {
    try {
        const { telegramId, itemId, price } = req.body;
        
        let userData = mockUsers.get(telegramId);
        if (!userData) {
            return res.status(404).json({ error: 'User not found' });
        }

        if (userData.soulCoins < price) {
            return res.status(400).json({ error: 'Insufficient soul coins' });
        }

        // Deduct coins
        userData.soulCoins -= price;

        // Add item to inventory
        switch (itemId) {
            case 'health_potion':
                userData.inventory.potions += 1;
                break;
            case 'spirit_shard':
                userData.inventory.spiritShards += 1;
                break;
            case 'shadow_fragment':
                userData.inventory.shadowFragments += 1;
                break;
            case 'ancient_artifact':
                userData.inventory.artifacts.push(`Artifact_${Date.now()}`);
                break;
        }

        mockUsers.set(telegramId, userData);

        // In production, save to Firebase
        try {
            await db.collection('users').doc(telegramId.toString()).update(userData);
        } catch (firebaseError) {
            console.log('Firebase update failed');
        }

        res.json({ success: true, user: userData });

    } catch (error) {
        console.error('Shop purchase error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Withdrawal simulation
app.post('/api/withdraw', async (req, res) => {
    try {
        const { telegramId, amount } = req.body;
        
        let userData = mockUsers.get(telegramId);
        if (!userData) {
            return res.status(404).json({ error: 'User not found' });
        }

        if (userData.soulCoins < amount) {
            return res.status(400).json({ error: 'Insufficient balance' });
        }

        // Simulate withdrawal (in real app, integrate with payment system)
        const withdrawalId = `withdrawal_${Date.now()}`;
        
        res.json({ 
            success: true, 
            message: 'Withdrawal request submitted (simulation only)',
            withdrawalId,
            amount,
            status: 'pending'
        });

    } catch (error) {
        console.error('Withdrawal error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('Server error:', error);
    res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Spiritual Shadow server running on port ${PORT}`);
    console.log(`Health check: http://localhost:${PORT}/health`);
});

module.exports = app;

